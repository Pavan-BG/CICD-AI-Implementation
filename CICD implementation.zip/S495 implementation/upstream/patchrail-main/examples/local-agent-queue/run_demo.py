from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any


ARTIFACTS = [
    "pilot-pack/failed-ci.redacted.log",
    "pilot-pack/patchrail-report.md",
    "pilot-pack/patchrail-result.json",
    "pilot-pack/pilot-manifest.json",
    "pilot-pack/README.md",
    "item.json",
    "item.md",
    "rejected-item.json",
    "rejected-item.md",
    "queue-before-decisions.json",
    "proposal.json",
    "proposal.md",
    "proposal-approved.json",
    "proposal-rejected.json",
    "proposal-rejected.md",
    "approved.json",
    "queue.jsonl",
    "audit-events.jsonl",
    "audit-summary.json",
    "gate-report.json",
    "gate-report.md",
    "bundle.json",
    "bundle.md",
]


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _json_file(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _run_patchrail(root: Path, args: list[str]) -> None:
    env = os.environ.copy()
    src = str(root / "src")
    existing_pythonpath = env.get("PYTHONPATH")
    env["PYTHONPATH"] = (
        src if not existing_pythonpath else f"{src}{os.pathsep}{existing_pythonpath}"
    )
    proc = subprocess.run(
        [sys.executable, "-m", "patchrail", *args],
        cwd=root,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        if proc.stdout:
            print(proc.stdout, file=sys.stderr, end="")
        if proc.stderr:
            print(proc.stderr, file=sys.stderr, end="")
        raise SystemExit(proc.returncode)
    if proc.stderr:
        print(proc.stderr, file=sys.stderr, end="")


def _prepare_output(output: Path, *, force: bool) -> None:
    output.mkdir(parents=True, exist_ok=True)
    generated = [
        output / "queue.sqlite",
        output / "queue.sqlite-wal",
        output / "queue.sqlite-shm",
        output / "init.json",
        output / "summary.json",
        *(output / artifact for artifact in ARTIFACTS),
    ]
    existing = [path for path in generated if path.exists()]
    if existing and not force:
        existing_names = ", ".join(path.name for path in existing)
        raise SystemExit(
            f"Output directory already contains demo artifacts: {existing_names}. "
            "Use --force or choose a new --output path."
        )
    for path in existing:
        path.unlink()


def run_demo(output: Path, *, force: bool = False) -> dict[str, Any]:
    root = _repo_root()
    output = output.resolve()
    _prepare_output(output, force=force)

    db = output / "queue.sqlite"
    pilot_pack = output / "pilot-pack"
    ci_result = pilot_pack / "patchrail-result.json"
    init_json = output / "init.json"
    item_json = output / "item.json"
    item_md = output / "item.md"
    rejected_item_json = output / "rejected-item.json"
    rejected_item_md = output / "rejected-item.md"
    queue_before_decisions_json = output / "queue-before-decisions.json"
    proposal_json = output / "proposal.json"
    proposal_md = output / "proposal.md"
    proposal_approved_json = output / "proposal-approved.json"
    proposal_rejected_json = output / "proposal-rejected.json"
    proposal_rejected_md = output / "proposal-rejected.md"
    approved_json = output / "approved.json"
    queue_jsonl = output / "queue.jsonl"
    audit_jsonl = output / "audit-events.jsonl"
    audit_summary_json = output / "audit-summary.json"
    gate_report_json = output / "gate-report.json"
    gate_report_md = output / "gate-report.md"
    bundle_json = output / "bundle.json"
    bundle_md = output / "bundle.md"
    summary_json = output / "summary.json"

    fixture_log = Path("examples") / "ci-triage" / "dependency-failure.log"
    _run_patchrail(
        root,
        [
            "ci",
            "pilot-pack",
            "--log",
            str(fixture_log),
            "--out-dir",
            str(pilot_pack),
        ],
    )
    _run_patchrail(root, ["queue", "--db", str(db), "init", "--out", str(init_json)])
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "add",
            "--from-pilot-pack",
            str(pilot_pack),
            "--payload-json",
            json.dumps({"markdown_report": "pilot-pack/patchrail-report.md"}, sort_keys=True),
            "--out",
            str(item_json),
        ],
    )
    item = _json_file(item_json)
    item_id = str(item["id"])

    _run_patchrail(
        root,
        ["queue", "--db", str(db), "show", item_id, "--format", "markdown", "--out", str(item_md)],
    )
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "add",
            "--kind",
            "ci_failure",
            "--title",
            "Review duplicate CI report",
            "--source",
            "local-demo",
            "--payload-json",
            json.dumps({"reason": "duplicate of approved local evidence"}, sort_keys=True),
            "--out",
            str(rejected_item_json),
        ],
    )
    rejected_item = _json_file(rejected_item_json)
    rejected_item_id = str(rejected_item["id"])
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "list",
            "--approval-state",
            "pending",
            "--format",
            "json",
            "--out",
            str(queue_before_decisions_json),
        ],
    )
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "show",
            rejected_item_id,
            "--format",
            "markdown",
            "--out",
            str(rejected_item_md),
        ],
    )
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "proposal",
            "add",
            "--item-id",
            item_id,
            "--title",
            "Pin compatible dependency range",
            "--summary",
            "Adjust dependency constraints and re-run the affected CI matrix.",
            "--patch-plan",
            "1. Reproduce the dependency install failure.\n"
            "2. Update the conflicting dependency range.\n"
            "3. Re-run the failing Python CI matrix.",
            "--risk-level",
            "low",
            "--out",
            str(proposal_json),
        ],
    )
    proposal = _json_file(proposal_json)
    proposal_id = str(proposal["id"])
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "proposal",
            "show",
            proposal_id,
            "--format",
            "markdown",
            "--out",
            str(proposal_md),
        ],
    )
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "proposal",
            "add",
            "--item-id",
            rejected_item_id,
            "--title",
            "Open a pull request immediately",
            "--summary",
            "Too broad for the local evidence and would skip maintainer review.",
            "--patch-plan",
            "1. Generate a patch.\n"
            "2. Open a pull request automatically.\n"
            "3. Ask for review after the write action.",
            "--risk-level",
            "high",
            "--out",
            str(proposal_rejected_json),
        ],
    )
    rejected_proposal = _json_file(proposal_rejected_json)
    rejected_proposal_id = str(rejected_proposal["id"])
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "proposal",
            "show",
            rejected_proposal_id,
            "--format",
            "markdown",
            "--out",
            str(proposal_rejected_md),
        ],
    )
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "proposal",
            "approve",
            proposal_id,
            "--note",
            "Maintainer approved the local patch plan.",
            "--out",
            str(proposal_approved_json),
        ],
    )
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "proposal",
            "reject",
            rejected_proposal_id,
            "--note",
            "Maintainer rejected the proposal because it attempted an automatic PR.",
            "--out",
            str(proposal_rejected_json),
        ],
    )
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "approve",
            item_id,
            "--note",
            "Maintainer reviewed the local CI evidence and approved handoff.",
            "--out",
            str(approved_json),
        ],
    )
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "reject",
            rejected_item_id,
            "--note",
            "Maintainer rejected the duplicate local queue item.",
            "--out",
            str(rejected_item_json),
        ],
    )
    _run_patchrail(
        root,
        ["queue", "--db", str(db), "export", "--format", "jsonl", "--out", str(queue_jsonl)],
    )
    _run_patchrail(
        root,
        ["queue", "--db", str(db), "audit", "--format", "jsonl", "--out", str(audit_jsonl)],
    )
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "audit-summary",
            "--format",
            "json",
            "--out",
            str(audit_summary_json),
        ],
    )
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "gate-report",
            "--format",
            "json",
            "--out",
            str(gate_report_json),
        ],
    )
    _run_patchrail(
        root,
        [
            "queue",
            "--db",
            str(db),
            "gate-report",
            "--format",
            "markdown",
            "--out",
            str(gate_report_md),
        ],
    )
    _run_patchrail(
        root,
        ["queue", "--db", str(db), "bundle", "--format", "json", "--out", str(bundle_json)],
    )
    _run_patchrail(
        root,
        ["queue", "--db", str(db), "bundle", "--format", "markdown", "--out", str(bundle_md)],
    )

    ci_payload = _json_file(ci_result)
    approved_item = _json_file(approved_json)
    rejected_item = _json_file(rejected_item_json)
    approved_proposal = _json_file(proposal_approved_json)
    rejected_proposal = _json_file(proposal_rejected_json)
    queue_before_decisions = _json_file(queue_before_decisions_json)
    audit_summary = _json_file(audit_summary_json)
    gate_report = _json_file(gate_report_json)
    bundle = _json_file(bundle_json)
    events = [json.loads(line) for line in audit_jsonl.read_text(encoding="utf-8").splitlines()]

    summary = {
        "schema_version": "patchrail.local_agent_queue_demo.v1",
        "local_first": True,
        "source_failure_class": ci_payload["failure_class"],
        "pending_items_before_decisions": len(queue_before_decisions["work_items"]),
        "item_approval_state": approved_item["approval_state"],
        "rejected_item_approval_state": rejected_item["approval_state"],
        "proposal_approval_state": approved_proposal["approval_state"],
        "proposal_risk_level": approved_proposal["risk_level"],
        "rejected_proposal_approval_state": rejected_proposal["approval_state"],
        "rejected_proposal_risk_level": rejected_proposal["risk_level"],
        "write_actions_allowed": approved_item["write_actions_allowed"],
        "rejected_item_write_actions_allowed": rejected_item["write_actions_allowed"],
        "audit_event_types": [event["event_type"] for event in events],
        "audit_summary_status": audit_summary["status"],
        "audit_summary_missing_required_events": audit_summary["missing_required_events"],
        "audit_summary_gates": audit_summary["gates"],
        "gate_report_status": gate_report["status"],
        "gate_report_ready_for_reviewer_handoff": gate_report["ready_for_reviewer_handoff"],
        "gate_report_pending_decisions": gate_report["pending_decisions"],
        "gate_report_missing_required_events": gate_report["missing_required_events"],
        "gate_report_is_read_only": gate_report["safety"]["report_is_read_only"],
        "gate_report_records_audit_event": gate_report["safety"]["report_records_audit_event"],
        "gate_report_execution_allowed": gate_report["safety"]["execution_allowed"],
        "bundle_status": bundle["status"],
        "bundle_remaining_gate_gaps": bundle["remaining_gate_gaps"],
        "bundle_reviewer_status": bundle["reviewer_summary"]["status"],
        "bundle_reviewer_human_gates_complete": bundle["reviewer_summary"]["human_gates_complete"],
        "bundle_reviewer_pending_decisions": bundle["reviewer_summary"]["pending_decisions"],
        "bundle_reviewer_execution_allowed": bundle["reviewer_summary"]["execution_allowed"],
        "bundle_is_read_only": bundle["safety"]["bundle_is_read_only"],
        "bundle_records_audit_event": bundle["safety"]["bundle_records_audit_event"],
        "bundle_local_paths_redacted": bundle["safety"]["local_paths_redacted"],
        "artifact_files": ARTIFACTS,
    }

    if summary["write_actions_allowed"]:
        raise AssertionError("Demo must not grant write actions.")
    if summary["item_approval_state"] != "approved":
        raise AssertionError("Work item approval was not recorded.")
    if summary["rejected_item_approval_state"] != "rejected":
        raise AssertionError("Work item rejection was not recorded.")
    if summary["proposal_approval_state"] != "approved":
        raise AssertionError("Proposal approval was not recorded.")
    if summary["rejected_proposal_approval_state"] != "rejected":
        raise AssertionError("Proposal rejection was not recorded.")
    if summary["audit_summary_status"] != "human_gates_exercised":
        raise AssertionError("Audit summary did not verify the local gate sequence.")
    if summary["audit_summary_missing_required_events"]:
        raise AssertionError("Audit summary must not miss required gate events.")
    if summary["gate_report_status"] != "ready_for_reviewer_handoff":
        raise AssertionError("Gate report must be ready after local human gates are exercised.")
    if not summary["gate_report_ready_for_reviewer_handoff"]:
        raise AssertionError("Gate report must mark the handoff reviewer-ready.")
    if summary["gate_report_pending_decisions"] != 0:
        raise AssertionError("Gate report must not leave pending reviewer decisions.")
    if summary["gate_report_missing_required_events"]:
        raise AssertionError("Gate report must not miss required gate events.")
    if not summary["gate_report_is_read_only"]:
        raise AssertionError("Gate report must remain read-only.")
    if summary["gate_report_records_audit_event"]:
        raise AssertionError("Reading the gate report must not append audit events.")
    if summary["gate_report_execution_allowed"]:
        raise AssertionError("Gate report must not allow execution.")
    if summary["bundle_status"] != "ready_for_handoff":
        raise AssertionError("Bundle must be ready for handoff after gate events.")
    if summary["bundle_remaining_gate_gaps"]:
        raise AssertionError("Bundle must not report remaining gate gaps.")
    if summary["bundle_reviewer_status"] != "ready_for_reviewer_handoff":
        raise AssertionError("Bundle reviewer summary must be ready for handoff.")
    if not summary["bundle_reviewer_human_gates_complete"]:
        raise AssertionError("Bundle reviewer summary must report complete human gates.")
    if summary["bundle_reviewer_pending_decisions"] != 0:
        raise AssertionError("Bundle reviewer summary must not leave pending decisions.")
    if summary["bundle_reviewer_execution_allowed"]:
        raise AssertionError("Bundle reviewer summary must not allow execution.")
    if not summary["bundle_is_read_only"]:
        raise AssertionError("Bundle must remain read-only.")
    if summary["bundle_records_audit_event"]:
        raise AssertionError("Reading the bundle must not append audit events.")
    if not summary["bundle_local_paths_redacted"]:
        raise AssertionError("Bundle must redact local paths.")

    summary_json.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return summary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run the local PatchRail Agent Control Plane demo end to end."
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(".patchrail-demo"),
        help="Directory for local demo artifacts. Defaults to .patchrail-demo.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite generated demo artifacts in the output directory.",
    )
    args = parser.parse_args(argv)
    summary = run_demo(args.output, force=args.force)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

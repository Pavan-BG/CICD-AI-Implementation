# Version 3 Windows evaluation: user-supplied result

**Provenance:** Reproduced from the user's terminal output and `REPORT_V3.md` screenshot in this conversation, using Windows 10, Python 3.12, `evaluate_v3.py`, 22 public logs and a pretrained MiniLM model. The full original `case_results_v3.csv` and `metrics_v3.json` from that Windows run were not uploaded; their numbers are **not fabricated or substituted** in this package. Use `RUN_WINDOWS_FULL.cmd` to generate these original machine-readable files for your own submission.

**Research status:** Exploratory post-hoc assessment. Rules were designed after analysing the same 22 cases, labels are provisional, and the V3 result is not independently validated.

| Method | Correct /22 | Correct (%) | Named coverage (%) | Incorrect named | Time/log including amortised setup (s) |
|---|---:|---:|---:|---:|---:|
| patchrail | 9/22 | 40.91 | 54.55 | 4 | 0.1772 |
| tfidf_v2 | 9/22 | 40.91 | 59.09 | 5 | 0.2970 |
| tfidf_v3 | 9/22 | 40.91 | 54.55 | 4 | 0.2960 |
| minilm_v2 | 9/22 | 40.91 | 63.64 | 5 | 1.1769 |
| minilm_v3 | 10/22 | 45.45 | 59.09 | 4 | 1.1799 |

**Interpretation:** V3 abstention handles one additional case correctly under the provisional labels, not an independently proven new root-cause diagnosis. V3 does not outperform the baseline in speed. New AI outputs remain investigation suggestions requiring human review. No live GitHub Actions run has been reported.

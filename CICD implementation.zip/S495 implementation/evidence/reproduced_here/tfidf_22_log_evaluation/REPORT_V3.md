# PatchRail AI V3 — post-hoc safety evaluation

**Not independent confirmation of accuracy improvement.** Evidence guard rules were designed after V2 error analysis of this same 22-log set. Labels are provisional.

| Method | Correct / 22 | Correct % | Named coverage | Wrong named | Mean time per log incl. amortized setup |
|---|---:|---:|---:|---:|---:|
| patchrail | 9/22 | 40.91% | 54.55% | 4 | 0.3802 s |
| tfidf_v2 | 9/22 | 40.91% | 59.09% | 5 | 0.5149 s |
| tfidf_v3 | 9/22 | 40.91% | 54.55% | 4 | 0.5579 s |

New AI categories and broad build hints are investigation suggestions requiring human verification, NOT confirmed root causes.

Evaluation scoring of broad labels may disagree with original PatchRail maintainer acceptance of abstentions.

Next step: separately collect and independently label new logs, pre-register rules, then measure true hold-out performance.

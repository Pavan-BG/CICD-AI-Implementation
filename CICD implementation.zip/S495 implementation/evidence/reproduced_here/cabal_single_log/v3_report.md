# PatchRail + AI V3: read-only diagnostic suggestion

- Original PatchRail: `unknown` (confidence 0.15)
- AI engine: `tfidf`
- AI candidate: `unknown`
- Suggested investigation family: `unknown`
- Decision: `manual_review`
- Evidence check: `not_applicable`
- Evidence explanation: Semantic similarity/margin did not meet fixed exploratory thresholds.
- Similarity (NOT a calibrated probability): `0.1831`
- Category margin: `0.0183`

## Recommended investigation
No reliable semantic candidate. Investigate CI failure manually.

## Supporting evidence (redacted excerpt)
```text
No category-specific confirming evidence.
```

## Safety and scientific limitations
All novel AI outputs require human verification and are only investigation suggestions. No production controls, CI failure status, retry, or deployment approval is changed.
The incident memory is fixture-derived synthetic material; resemblance does not establish root cause. Research labels require independent verification.

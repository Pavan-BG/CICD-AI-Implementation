# Figure index for the thesis evidence

These are user-supplied screenshots and plots from local Windows runs. They are not images of independently repeated MiniLM inference in the packaging environment.

| Evidence file | Figure | Description |
|---|---|---|
| `Figure_01.png` | 1 | PatchRail original: 223 supplied fixture cases passed |
| `Figure_02.png` | 2 | Python prototype: 8 unit tests passed |
| `Figure_03.png` | 3 | TF-IDF standalone diagnosis terminal |
| `Figure_04.png` | 4 | MiniLM standalone diagnosis report |
| `Figure_05.png` | 5 | TF-IDF standalone diagnosis report |
| `Figure_06.png` | 6 | MiniLM standalone execution terminal |
| `Figure_07.png` | 7 | Known failure: PatchRail baseline retained |
| `Figure_08.png` | 8 | Unknown failure: PatchRail to MiniLM integration |
| `Figure_09.png` | 9 | Real Symfony failure MiniLM integration terminal |
| `Figure_10.png` | 10 | Real Symfony failure AI report manual review |
| `Figure_11.png` | 11 | Original PatchRail Symfony JSON report |
| `Figure_12.png` | 12 | V1 two-method mean processing time |
| `Figure_13.png` | 13 | V1 two-method classification correctness |
| `Figure_14.png` | 14 | V1 two-method named coverage |
| `Figure_15.png` | 15 | V2 five-method processing time |
| `Figure_16.png` | 16 | V2 incorrect named suggestions |
| `Figure_17.png` | 17 | V2 classification correctness |
| `Figure_18.png` | 18 | V2 named coverage |
| `Figure_19.png` | 19 | V3 classification correctness |
| `Figure_20.png` | 20 | V3 named coverage |
| `Figure_21.png` | 21 | V3 incorrect named diagnoses |
| `Figure_22.png` | 22 | V3 processing time |

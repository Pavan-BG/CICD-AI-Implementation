# PatchRail V2 case-level audit

Input: `C:\Users\Administrator\Downloads\PatchRail_AI_V2_Improved_Evaluation\PatchRail_AI_V2\results_windows_v2\case_results.csv`
Cases: 22

**Interpretation:** This file does not change the saved experiment or prove an accuracy improvement. All correctness counts below use provisional researcher-coarsened labels; the original maintainer accepts several deliberate `unknown` verdicts and several different-category named verdicts.

| Method | Named | Correct (provisional) | Incorrect named (provisional) | New named vs PatchRail |
|---|---:|---:|---:|---:|
| patchrail | 12/22 | 9/22 | 4 | 0 |
| minilm_v1 | 11/22 | 8/22 | 4 | 0 |
| minilm_v2 | 14/22 | 9/22 | 5 | 2 |
| tfidf_v1 | 11/22 | 8/22 | 4 | 0 |
| tfidf_v2 | 13/22 | 9/22 | 5 | 1 |

## Additional diagnoses on logs PatchRail left unknown

| File | Method | New diagnosis | Provisional ground truth | Score | Evidence check |
|---|---|---|---|---|---|
| pandas-29342614636.log | minilm_v2 | `artifact_or_cache_failure` | `insufficient_evidence` | incorrect | accept_for_human_review |
| riverpod-29573819047-excerpt.log | tfidf_v2 | `release_publish_failure` | `lint_failure` | incorrect | reject_unsupported |
| cabal-29562439929-excerpt.log | minilm_v2 | `docker_build_failure` | `build_failure` | correct | accept_for_human_review |

## Post-hoc evidence-guard sensitivity (exploratory only)

| Method | Named before → after | Incorrect named before → after | Correct before → after |
|---|---|---|---|
| patchrail | 12 → 12 | 4 → 4 | 9 → 9 |
| minilm_v1 | 11 → 11 | 4 → 4 | 8 → 8 |
| minilm_v2 | 14 → 14 | 5 → 5 | 9 → 9 |
| tfidf_v1 | 11 → 11 | 4 → 4 | 8 → 8 |
| tfidf_v2 | 13 → 12 | 5 → 4 | 9 → 9 |

**This is an after-the-fact safety preview using test logs, not independently validated new performance.** Any rule selected after reviewing these errors needs new validation/test logs before claiming an improvement.

## Existing and newly introduced wrong named diagnoses (provisional labels)

| File | Method | Named class | Provisional truth |
|---|---|---|---|
| pandas-29342614636.log | minilm_v2 | `artifact_or_cache_failure` | `insufficient_evidence` |
| grafana-27635190952.log | patchrail | `go_test_failure` | `build_failure` |
| grafana-27635190952.log | minilm_v1 | `go_test_failure` | `build_failure` |
| grafana-27635190952.log | minilm_v2 | `go_test_failure` | `build_failure` |
| grafana-27635190952.log | tfidf_v1 | `go_test_failure` | `build_failure` |
| grafana-27635190952.log | tfidf_v2 | `go_test_failure` | `build_failure` |
| mastodon-29561949942-excerpt.log | patchrail | `ruby_bundle_failure` | `test_failure` |
| mastodon-29561949942-excerpt.log | minilm_v1 | `ruby_bundle_failure` | `test_failure` |
| mastodon-29561949942-excerpt.log | minilm_v2 | `ruby_bundle_failure` | `test_failure` |
| mastodon-29561949942-excerpt.log | tfidf_v1 | `ruby_bundle_failure` | `test_failure` |
| mastodon-29561949942-excerpt.log | tfidf_v2 | `ruby_bundle_failure` | `test_failure` |
| signal-android-28969358490-excerpt.log | patchrail | `java_build_failure` | `test_failure` |
| signal-android-28969358490-excerpt.log | minilm_v1 | `java_build_failure` | `test_failure` |
| signal-android-28969358490-excerpt.log | minilm_v2 | `java_build_failure` | `test_failure` |
| signal-android-28969358490-excerpt.log | tfidf_v1 | `java_build_failure` | `test_failure` |
| signal-android-28969358490-excerpt.log | tfidf_v2 | `java_build_failure` | `test_failure` |
| cats-29545595453-excerpt.log | patchrail | `java_build_failure` | `test_failure` |
| cats-29545595453-excerpt.log | minilm_v1 | `java_build_failure` | `test_failure` |
| cats-29545595453-excerpt.log | minilm_v2 | `java_build_failure` | `test_failure` |
| cats-29545595453-excerpt.log | tfidf_v1 | `java_build_failure` | `test_failure` |
| cats-29545595453-excerpt.log | tfidf_v2 | `java_build_failure` | `test_failure` |
| riverpod-29573819047-excerpt.log | tfidf_v2 | `release_publish_failure` | `lint_failure` |

## Evidence-based safety review

The guard preview checks ONLY new AI suggestions while leaving all PatchRail original named diagnoses unchanged. For `release_publish_failure`, a real failed publish/release operation must appear in the log. Cases without source logs are **not verified**. Other categories still require human review.

**Do not tune thresholds against these same 22 logs and then call the results independent performance.** Design any changes using separate validation examples and retest on new, untouched logs.

## Label validity concern

The PatchRail maintainer explicitly treats 10 `unknown` outcomes as deliberate, acceptable abstentions, including Symfony, Discourse, Riverpod and Cabal. The original research scoring treats many of those as incorrect because the maintainer has no matching failure class. Mastodon, Signal-Android and cats also receive broad class labels that the maintainer describes as acceptable but the strict study mapping penalises. These are different evaluation questions and should not be conflated.

## How to complete independent verification

Open `independent_label_review_template.csv`. Have a reviewer who did not create the model label each log from its failure evidence, including an `insufficient_evidence` option and an explicit agreed taxonomy. Record differences from the provisional labels. Do not replace source predictions or modify the 22 logs.


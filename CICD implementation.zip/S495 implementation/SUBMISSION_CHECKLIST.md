# Submission checklist

- [x] Original upstream source, tests, documentation, licence and curated fixtures included unchanged.
- [x] External V3 implementation and earlier comparison modules included.
- [x] Public real-world evaluation logs bundled with upstream repository.
- [x] 96 synthetic memory records and 22 provisional research labels included.
- [x] Original 223-case benchmark and 16 V3 unit tests re-run successfully during package construction.
- [x] Local TF-IDF V2/V3 case-level CSV, metrics, graphs and sample logs reproduced.
- [x] Researcher's existing MiniLM Windows result screenshot, four graphs and 22 thesis figures included.
- [x] Case-level audit, incorrect prediction analysis and independent label-review template included.
- [x] One-click Windows setup, offline and full-run scripts included.
- [x] Optional GitHub Actions demonstration workflow supplied, not claimed as executed.
- [ ] Run the full MiniLM comparison from this ZIP on the target computer and retain resulting original CSV/JSON files.
- [ ] Conduct an independent held-out validation if making performance generalisation claims.
- [ ] Execute a real hosted workflow before describing GitHub Actions as demonstrated.
- [ ] Complete author names / institutional disclosure / tool-use statement accurately.

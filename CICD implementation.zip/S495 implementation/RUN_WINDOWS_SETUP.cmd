@echo off
setlocal
set "ROOT=%~dp0"
set "IMPL=%ROOT%implementation\PatchRail_AI_V3"
echo Installing Python dependencies for reproducibility...
python --version || (echo ERROR: Install Python 3.11 or newer. & exit /b 1)
python -m pip install -r "%IMPL%\requirements-v2.txt" || exit /b 1
python -m pip install -r "%IMPL%\requirements-minilm.txt" || exit /b 1
echo Setup complete. Hugging Face model weights download during the first MiniLM run.
exit /b 0

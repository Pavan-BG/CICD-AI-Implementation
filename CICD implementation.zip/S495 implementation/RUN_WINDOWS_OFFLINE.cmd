@echo off
setlocal
set "ROOT=%~dp0"
set "UPSTREAM=%ROOT%upstream\patchrail-main"
set "IMPL=%ROOT%implementation\PatchRail_AI_V3"
set "OUT=%ROOT%RUN_OUTPUT_OFFLINE"
if not exist "%OUT%" mkdir "%OUT%"
set "PYTHONPATH=%UPSTREAM%\src;%PYTHONPATH%"
pushd "%UPSTREAM%"
python -m patchrail ci benchmark examples/ci-triage --format json > "%OUT%\patchrail_benchmark.json"
if errorlevel 1 (popd & echo Baseline benchmark failed. & exit /b 1)
popd
pushd "%IMPL%"
python -m pytest -q tests > "%OUT%\unit_tests.txt" 2>&1
if errorlevel 1 (popd & type "%OUT%\unit_tests.txt" & exit /b 1)
popd
python "%IMPL%\evaluate_v3.py" --patchrail-root "%UPSTREAM%" --engines tfidf --output-dir "%OUT%\comparison"
if errorlevel 1 exit /b 1
echo Offline evaluation complete in "%OUT%". MiniLM NOT run.
exit /b 0

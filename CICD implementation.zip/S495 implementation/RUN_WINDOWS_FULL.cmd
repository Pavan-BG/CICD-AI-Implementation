@echo off
setlocal
set "ROOT=%~dp0"
set "UPSTREAM=%ROOT%upstream\patchrail-main"
set "IMPL=%ROOT%implementation\PatchRail_AI_V3"
set "OUT=%ROOT%RUN_OUTPUT"
if not exist "%UPSTREAM%\src\patchrail" (echo Missing upstream PatchRail source. & exit /b 1)
if not exist "%IMPL%\evaluate_v3.py" (echo Missing V3 code. & exit /b 1)
if not exist "%OUT%" mkdir "%OUT%"
set "PYTHONPATH=%UPSTREAM%\src;%PYTHONPATH%"
echo [1/4] Original PatchRail 223-fixture benchmark...
pushd "%UPSTREAM%"
python -m patchrail ci benchmark examples/ci-triage --format json > "%OUT%\patchrail_benchmark.json"
if errorlevel 1 (popd & echo PatchRail benchmark failed. & exit /b 1)
popd
echo [2/4] V3 Python tests...
pushd "%IMPL%"
python -m pytest -q tests > "%OUT%\unit_tests.txt" 2>&1
if errorlevel 1 (popd & type "%OUT%\unit_tests.txt" & echo Tests failed. & exit /b 1)
popd
type "%OUT%\unit_tests.txt"
echo [3/4] Five-method original/TF-IDF/MiniLM comparative evaluation...
python "%IMPL%\evaluate_v3.py" --patchrail-root "%UPSTREAM%" --engines tfidf minilm --output-dir "%OUT%\comparison" > "%OUT%\comparison_console.txt" 2>&1
if errorlevel 1 (type "%OUT%\comparison_console.txt" & echo Evaluation failed. Check Python dependencies and Internet/model cache. & exit /b 1)
type "%OUT%\comparison\REPORT_V3.md"
echo [4/4] Single-log read-only MiniLM integration demonstration...
python "%IMPL%\integrate_v3.py" --patchrail-root "%UPSTREAM%" --log "%UPSTREAM%\examples\real-world\cabal-29562439929-excerpt.log" --engine minilm --out-dir "%OUT%\single_log_cabal" > "%OUT%\single_log_console.txt" 2>&1
if errorlevel 1 (type "%OUT%\single_log_console.txt" & echo Single-log integration failed. & exit /b 1)
type "%OUT%\single_log_console.txt"
echo.
echo Complete. Evidence folder: "%OUT%"
echo NOT independent validation: V3 was developed after reviewing these evaluation cases.
exit /b 0

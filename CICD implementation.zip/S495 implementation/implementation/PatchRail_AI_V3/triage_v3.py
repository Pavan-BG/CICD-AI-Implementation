"""Version 3: evidence-checked AI *investigation suggestions*, never release approval."""
from __future__ import annotations
from dataclasses import asdict
from typing import Any
from enhanced_triage import Retriever
from evidence_gate_v3 import check_evidence


def triage_v3(log: str, baseline_class: str, baseline_confidence: float,
              retriever: Retriever, similarity_threshold: float = 0.52,
              margin_threshold: float = 0.025) -> dict[str,Any]:
    base = retriever.predict(log, baseline_class, baseline_confidence,
                             similarity_threshold, margin_threshold)
    res = dict(base)
    res.update(version='V3', ai_confirmed_root_cause=False, human_review_required=False,
               candidate_category='unknown', evidence_decision='not_applicable',
               evidence_reason='', evidence_lines=[],
               evaluation_label='baseline' if base['status']=='baseline_kept' else 'insufficient_evidence')
    if base['status']=='baseline_kept':
        res['evidence_reason']='Original named PatchRail classification preserved unchanged.'
        res['evaluation_label']=base['predicted_category']
        return res
    res['human_review_required']=True
    if base['status']!='ai_suggestion_review_required':
        res['status']='manual_review'
        res['predicted_category']='unknown'
        res['suggested_action']='No reliable semantic candidate. Investigate CI failure manually.'
        res['evidence_reason']='Semantic similarity/margin did not meet fixed exploratory thresholds.'
        return res
    candidate=base['predicted_category']
    res['candidate_category']=candidate
    evidence=check_evidence(candidate, log)
    res['evidence_decision']=evidence.decision
    res['evidence_reason']=evidence.reason
    res['evidence_lines']=evidence.evidence_lines
    if evidence.decision=='supported_specific':
        res['status']='ai_evidence_supported_review_required'
        res['predicted_category']=candidate
        res['evaluation_label']=candidate
        res['suggested_action']='Review the source evidence and verify this *suggested* category; do not automatically repair or approve a release.'
    elif evidence.decision=='broad_build_only':
        res['status']='ai_broad_build_hint_review_required'
        res['predicted_category']='build_failure'  # a broad investigation family, NOT a Docker failure
        res['evaluation_label']='build_failure'
        res['suggested_action']='The build step failed, but the AI suggested tool-specific cause is unsupported. Investigate the build failure manually.'
    else:
        res['status']='manual_review_unsupported_ai_candidate'
        res['predicted_category']='unknown'
        res['evaluation_label']='insufficient_evidence'
        res['suggested_action']='AI suggestion rejected because the actual log lacks confirming error evidence. Review manually.'
    # Never change CI status or automatically accept diagnosis.
    res['changes_ci_status']=False
    res['auto_retry']=False
    res['ai_confirmed_root_cause']=False
    res['human_review_required']=True
    return res


def markdown(report: dict[str,Any]) -> str:
    def safe(s):
        return str(s).replace('`','\'')
    lines=[
       '# PatchRail + AI V3: read-only diagnostic suggestion',
       '',f'- Original PatchRail: `{safe(report["baseline_class"])}` (confidence {report["baseline_confidence"]:.2f})',
       f'- AI engine: `{safe(report["engine"])}`',
       f'- AI candidate: `{safe(report["candidate_category"])}`',
       f'- Suggested investigation family: `{safe(report["predicted_category"])}`',
       f'- Decision: `{safe(report["status"])}`',
       f'- Evidence check: `{safe(report["evidence_decision"])}`',
       f'- Evidence explanation: {safe(report["evidence_reason"])}',
       f'- Similarity (NOT a calibrated probability): `{report.get("similarity")}`',
       f'- Category margin: `{report.get("similarity_margin")}`',
       '', '## Recommended investigation', report['suggested_action'],
       '', '## Supporting evidence (redacted excerpt)', '```text']
    lines += [safe(x) for x in report['evidence_lines']] or ['No category-specific confirming evidence.']
    lines += ['```','','## Safety and scientific limitations',
       'All novel AI outputs require human verification and are only investigation suggestions. No production controls, CI failure status, retry, or deployment approval is changed.',
       'The incident memory is fixture-derived synthetic material; resemblance does not establish root cause. Research labels require independent verification.']
    return '\n'.join(lines)+'\n'

"""Source-grounded, read-only evidence gates for *suggested* CI failure categories.

Never interprets semantic similarity as a probability. Only independently visible
log signals can support a new suggestion. Generic family fallback is permitted
for specific build-tool guesses when an actual build command failed; tool-specific
root cause remains unverified. All new suggestions require human review.

Rules are exploratory engineering controls, not an independently validated model.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Optional
import re

ANSI = re.compile(r'\x1b\[[0-9;]*[A-Za-z]')
PREFIX = re.compile(r'^.*?(?:UNKNOWN STEP\s+\d{4}-\d{2}-\d{2}T\S+\s+|\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?\s+)')
# Generic 'error' by itself is not enough to assert an exact subtype.
FAIL = re.compile(r'(?i)(\bfail(?:ed|ure|ing)?\b|\berror\b|\bfatal\b|\bdenied\b|\bforbidden\b|\bcannot\b|\bcould not\b|\btimed?\s*out\b|\bexception\b|\bno matching distribution\b|\bexit (?:code|status) [1-9]\b|\bpanic\b|\bunsuccessful\b)')
PATTERNS = {
    'artifact_or_cache_failure': r'(?i)(?:\b(?:cache|artifact)\b.{0,90}\b(?:failed|failure|error|denied|corrupt|not found|cannot|could not)\b|\b(?:failed|error|cannot|could not|denied)\b.{0,90}\b(?:cache|artifact)\b)',
    'docker_build_failure': r'(?i)(?:\b(?:docker\s+build|dockerfile|buildkit|failed to solve|docker\s+buildx)\b.{0,150}\b(?:failed|error|denied|cannot|could not|no such file)\b|\b(?:failed to solve|docker build failed|docker buildx build failed)\b)',
    'release_publish_failure': r'(?i)(?:\b(?:npm publish|twine upload|gh release|docker push|pypi upload|release publish|publish|publishing|deploy|deployment|upload artifact)\b.{0,120}\b(?:failed|failure|error|denied|forbidden|unauthorized|cannot|could not|rejected)\b|\b(?:failed|error|denied|rejected|unauthorized)\b.{0,100}\b(?:publish|release|deploy|docker push)\b)',
    'python_dependency_resolution': r'(?i)(?:\b(?:pip install|pip-compile|poetry install|uv sync|resolutionimpossible|no matching distribution found|could not find a version that satisfies|conflicting dependencies|cannot install.+conflict)\b.{0,140}\b(?:failed|error|conflict|could not|cannot|no matching|unsatisfiable|resolution)\b|\b(?:resolutionimpossible|no matching distribution found|could not find a version that satisfies)\b)',
    'node_dependency_install': r'(?i)(?:\b(?:npm ci|npm install|pnpm install|yarn install|eresolve|enotfound|cannot resolve dependency)\b.{0,140}\b(?:failed|error|eresolve|enotfound|unable|conflict)\b|\b(?:eresolve|npm err!|yarn error)\b)',
    'ruby_bundle_failure': r'(?i)(?:\b(?:bundler|bundle install|gem install)\b.{0,100}\b(?:failed|error|could not find|dependency conflict)\b|\bcould not find gem\b)',
    'security_scan_failure': r'(?i)(?:\b(?:trivy|snyk|cargo audit|pip-audit|npm audit|security scan|vulnerability scan)\b.{0,120}\b(?:failed|error|critical|vulnerabilit|severity)\b|\b(?:vulnerability|cve-\d{4}-\d+)\b.{0,80}\b(?:critical|high|scan failed)\b)',
    'browser_test_failure': r'(?i)(?:\b(?:playwright|cypress|selenium|webdriver|browser test)\b.{0,120}\b(?:failed|error|timeout|timed out|assertion)\b|\b(?:locator|page\.waitForSelector|element not found)\b.{0,100}\b(?:timeout|failed|error)\b)',
    'typescript_typecheck': r'(?i)(?:\b(?:tsc|typescript|typecheck)\b.{0,120}\b(?:failed|error|ts\d{4})\b|\berror ts\d{4}:)',
    'javascript_lint': r'(?i)(?:\b(?:eslint|prettier|javascript lint|npm run lint)\b.{0,120}\b(?:failed|error|problem|warning)\b)',
    'go_lint': r'(?i)\b(?:golangci-lint|go vet|go fmt|go lint)\b.{0,120}\b(?:failed|error|issue)\b',
    'shell_lint': r'(?i)\b(?:shellcheck|shfmt)\b.{0,120}\b(?:failed|error|sc\d{4})\b',
    'go_test_failure': r'(?i)(?:\bgo test\b.{0,120}\b(?:fail|error)\b|--- fail:|\bFAIL\s+\S+)',
    'rust_test_failure': r'(?i)(?:\bcargo test\b.{0,120}\b(?:fail|error|panic)\b|\bthread .+ panicked at\b|\btest result: FAILED\b)',
    'python_test_failure': r'(?i)(?:\bpytest\b.{0,120}\b(?:fail|error|assert)\b|\bassertionerror\b|\b\d+ failed, \d+ passed\b)',
    'node_test_failure': r'(?i)(?:\b(?:jest|vitest|mocha|npm test)\b.{0,120}\b(?:failed|error|assert)\b|\btest suites: \d+ failed\b)',
    'database_migration_failure': r'(?i)\b(?:migration|migrate|flyway|alembic)\b.{0,120}\b(?:failed|error|rollback)\b',
    'kubernetes_deploy_failure': r'(?i)\b(?:kubectl|helm upgrade|kubernetes|pod rollout)\b.{0,120}\b(?:failed|error|timeout|denied)\b',
    'helm_chart_failure': r'(?i)\b(?:helm template|helm lint|chart\.yaml|helm install)\b.{0,120}\b(?:failed|error|invalid)\b',
    'terraform_iac_failure': r'(?i)\b(?:terraform plan|terraform apply|terraform validate|terraform init)\b.{0,120}\b(?:failed|error|denied|invalid)\b',
    'ci_job_timeout': r'(?i)(?:\b(?:job|workflow|runner|step)\b.{0,100}\b(?:timed out|timeout exceeded|time limit exceeded)\b|\boperation timed out\b)',
}
RULES = {k: re.compile(v) for k,v in PATTERNS.items()}
# Tool-specific classes not listed above are not automatically accepted. They may
# receive a broad *unverified investigation hint* only when a concrete error exists.
BUILD_TOOLS = {'docker_build_failure','php_composer_failure','java_build_failure','dotnet_build_failure',
               'cpp_build_failure','xcode_build_failure','docs_build_failure','elixir_mix_failure'}
# Specific failed build step signal, not merely a job named "build".
GENERIC_BUILD = re.compile(r'(?i)(?:\b(?:cabal\s+(?:v2-)?build|ghc\s+--make|cargo\s+build|dotnet\s+build|mvn\s+(?:compile|package)|gradle\s+build|cmake\s+--build)\b.{0,220}\b(?:fail(?:ed)?|error|exception)\b|\b(?:compilation|compile|build)\b.{0,100}\b(?:failed|failure|error)\b|\b(?:failed|error)\b.{0,80}\b(?:compilation|compile|build)\b)')
GENERIC_LINT = re.compile(r'(?i)(?:\b(?:flutter analyze|dart analyze|eslint|golangci-lint)\b.{0,150}\b(?:error|fail|issues? found)\b|\b\d+ issues? found\b)')
GENERIC_TEST = re.compile(r'(?i)(?:\b(?:test|tests|pytest|phpunit|rspec)\b.{0,110}\b(?:failed|failure|assertion|error)\b|\bfailed asserting\b|\bthere was \d+ failures?\b)')

@dataclass(frozen=True)
class Evidence:
    decision: str   # supported_specific, broad_build_only, unsupported
    category: str   # specific, broad build_failure, or unknown
    reason: str
    evidence_lines: list[str]

    def to_dict(self): return asdict(self)


def normalized_lines(log: str) -> list[str]:
    lines=[]
    for raw in ANSI.sub('',log).splitlines():
        raw = PREFIX.sub('',raw)
        raw = re.sub(r'\s+', ' ', raw).strip()
        if raw: lines.append(raw[:750])
    return lines


def check_evidence(category: str, log: str) -> Evidence:
    """Inspect actual log evidence, never a file name or a benchmark truth label."""
    # Warnings can describe recoverable cache/publish events. They are NOT
    # evidence that the CI job failed. Filter warning-only lines before linking
    # a proposed failure category with the actual failing operation.
    lines=[s for s in normalized_lines(log) if not re.search(r'(?i)(?:##\[warning\]|^warning\s*:|\bWARN(?:ING)?\s*[:\]])',s)]
    if not lines:
        return Evidence('unsupported','unknown','No nonempty failure log',[])
    # Require genuine near-error evidence; a string like 'Cache' in normal setup
    # chatter alone is not enough. Restrict to the latest failing context.
    signal_lines=[(i,s) for i,s in enumerate(lines) if FAIL.search(s)]
    if not signal_lines:
        return Evidence('unsupported','unknown','Log contains no explicit error/failure markers',[])
    # For scripts that report wrapped errors, check 2-line windows around each.
    windows=[]
    for i,_ in signal_lines[-65:]:
        start=max(0,i-1); end=min(len(lines),i+2)
        joined=' | '.join(lines[start:end])
        windows.append((i,joined))
    rule=RULES.get(category)
    if rule is not None:
        # High-risk, easily confused operations require a same-line causal cue.
        # A successful cache/release step next to an unrelated failed test is
        # not sufficient support for a cache/release diagnosis.
        strict={'artifact_or_cache_failure','docker_build_failure','release_publish_failure'}
        possible=([lines[i] for i,_ in signal_lines[-65:]] if category in strict
                  else [s for _,s in windows])
        matched=[s for s in possible if rule.search(s)]
        if matched:
            # Docker-specific result can not be inferred from generic build text.
            return Evidence('supported_specific',category,'Matching failed operation appears in CI log',matched[-2:])
    # Generic build family fallback is a distinct *investigation hint*, not a
    # Docker/PHP/Java root-cause claim.  Named only as a broad research label.
    if category in BUILD_TOOLS:
        generic=[s for _,s in windows if GENERIC_BUILD.search(s)]
        if generic:
            return Evidence('broad_build_only','build_failure',
                f'{category} lacks specific evidence; failed build step is visible. Tool-specific cause unverified.',generic[-2:])
    return Evidence('unsupported','unknown',
       f'No failed operation supports the specific proposed category: {category}',
       [s for _,s in signal_lines[-2:]])

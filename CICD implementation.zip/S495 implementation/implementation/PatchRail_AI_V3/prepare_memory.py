"""Build *fixture-derived*, not independently verified, incident memory.

Only PatchRail's own 223 synthetic fixture logs are considered. None of the
22 separate real-world benchmark logs is included. Provenance travels with each
record. Do NOT describe fixture records as real production incidents.
"""
from __future__ import annotations
import argparse
import json
import re
from collections import Counter
from pathlib import Path
from ai_triage import redact


def build_memory(root: Path, max_per_class: int = 4) -> list[dict]:
    base = root / 'examples' / 'ci-triage'
    if not base.is_dir():
        raise FileNotFoundError(f'Fixture folder not found: {base}')
    records = []
    counter: Counter[str] = Counter()
    for file in sorted(base.glob('*.expected.json')):
        label = json.loads(file.read_text(encoding='utf-8')).get('failure_class', '')
        log_file = base / file.name.replace('.expected.json', '.log')
        if not log_file.is_file() or label in ('unknown', '', None) or counter[label] >= max_per_class:
            continue
        log = redact(log_file.read_text(encoding='utf-8', errors='replace'))
        if not log.strip():
            continue
        records.append({
            'id': f'F{len(records)+1:03}', 'category': label,
            'log': log[:16000], 'advice': 'Inspect the specific failing stage and reproduce this error locally; validate a fix before approval.',
            'source_type': 'patchrail_synthetic_fixture',
            'source_file': f'examples/ci-triage/{log_file.name}',
            'label_source': f'examples/ci-triage/{file.name}',
        })
        counter[label] += 1
    return records


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument('--patchrail-root', required=True, type=Path)
    p.add_argument('--max-per-class', type=int, default=4)
    p.add_argument('--output', default='data/fixture_memory.jsonl', type=Path)
    a = p.parse_args()
    if a.max_per_class < 1: p.error('--max-per-class must be >=1')
    records = build_memory(a.patchrail_root, a.max_per_class)
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in records), encoding='utf-8')
    print(f'Wrote {len(records)} labelled *synthetic* fixture memories, {len(set(r["category"] for r in records))} classes -> {a.output}')
    print('None are independently verified real-world cases. Do not mix in 22 real-world test logs.')

if __name__ == '__main__': main()

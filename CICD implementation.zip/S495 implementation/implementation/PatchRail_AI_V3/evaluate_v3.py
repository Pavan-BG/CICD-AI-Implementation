"""Exploratory V2 vs V3 comparison on unchanged original 22 logs.

WARNING: V3 evidence rules were designed after examining V2 test errors.
Results on these 22 logs are post-hoc and NOT an independent generalization test.
"""
import argparse,csv,json,sys,time
from pathlib import Path
from statistics import mean
from enhanced_triage import Retriever
from triage_v3 import triage_v3
from ai_triage import load_memory
from evaluate import coarse

HERE=Path(__file__).resolve().parent

def category_to_coarse(label:str)->str:
    if label == 'build_failure':return 'build_failure'  # V3 broad hint, not a named root-cause claim
    return coarse(label)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--patchrail-root',required=True,type=Path)
    p.add_argument('--engines',nargs='+',choices=['tfidf','minilm'],default=['tfidf','minilm'])
    p.add_argument('--output-dir',type=Path,default=Path('results_v3'))
    a=p.parse_args(); root=a.patchrail_root.resolve()
    if not (root/'examples'/'real-world').is_dir():p.error('PatchRail real-world log directory not found')
    if not (root/'src'/'patchrail').is_dir():p.error('PatchRail src directory not found')
    sys.path.insert(0,str(root/'src'))
    from patchrail.ci.classify import classify_ci_log,redact_ci_log
    cases=json.loads((HERE/'data'/'ground_truth.json').read_text(encoding='utf-8'))['cases']
    test_names={x['file'] for x in cases}
    incidents=load_memory(HERE/'data'/'fixture_memory.jsonl')
    collisions=[x.get('source_file') for x in incidents if Path(x.get('source_file','')).name in test_names]
    if collisions:raise ValueError(f'Memory/test overlap: {collisions}')
    retrievers={};setup={}
    for e in a.engines:
        t=time.perf_counter();retrievers[e]=Retriever(incidents,e);setup[e]=time.perf_counter()-t
        print(f'{e}: {len(incidents)} synthetic memories indexed in {setup[e]:.2f}s',flush=True)
    rows=[]
    for i,case in enumerate(cases,1):
        path=root/'examples'/'real-world'/case['file']
        if not path.is_file():raise FileNotFoundError(path)
        raw=path.read_text(encoding='utf-8',errors='replace')
        t=time.perf_counter();baseline=classify_ci_log(raw); btime=time.perf_counter()-t
        clean=redact_ci_log(raw)['text']
        bc=baseline.get('failure_class') or 'unknown'; conf=float(baseline.get('confidence') or 0)
        def record(method,category,status,secs,candidate='',evidence='',similarity=None,margin=None):
            broad=category_to_coarse(category)
            rows.append(dict(file=case['file'],truth=case['truth'],truth_description=case['reason'],method=method,
                baseline=bc,baseline_confidence=conf,predicted=category,predicted_coarse=broad,
                correct=int(broad==case['truth']),named=int(broad!='insufficient_evidence'),
                status=status,candidate=candidate,evidence_decision=evidence,
                seconds=round(secs,5),similarity=similarity,margin=margin))
        record('patchrail',bc,'baseline',btime)
        for engine,r in retrievers.items():
            t=time.perf_counter()
            v2=r.predict(clean,bc,conf)
            duration=time.perf_counter()-t
            record(f'{engine}_v2',v2['predicted_category'],v2['status'],btime+duration,
                v2.get('predicted_category'),'',v2.get('similarity'),v2.get('similarity_margin'))
            t=time.perf_counter();v3=triage_v3(clean,bc,conf,r)
            record(f'{engine}_v3',v3['predicted_category'],v3['status'],btime+time.perf_counter()-t,
                v3['candidate_category'],v3['evidence_decision'],v3.get('similarity'),v3.get('similarity_margin'))
        print(f'[{i:02}/{len(cases)}] {case["file"]}',flush=True)
    a.output_dir.mkdir(parents=True,exist_ok=True)
    with (a.output_dir/'case_results_v3.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    methods=['patchrail']+[f'{e}_{v}' for e in a.engines for v in ('v2','v3')]
    results=[]
    for method in methods:
        part=[r for r in rows if r['method']==method];n=len(part)
        named=[r for r in part if r['named']]
        wrong=sum(not r['correct'] for r in named)
        secs=mean(r['seconds'] for r in part)
        warm=setup.get(method.replace('_v2','').replace('_v3',''),0)
        results.append(dict(method=method,n=n,correct=sum(r['correct'] for r in part),
            correct_pct=round(100*sum(r['correct'] for r in part)/n,2),
            named=len(named),coverage_pct=round(100*len(named)/n,2),
            wrong_named=wrong,correct_named=sum(r['correct'] for r in named),
            mean_seconds=round(secs,4),amortized_setup_seconds=round((secs + warm/n),4),
            accepted_ai_root_causes=0))
    data={'warning':'POST-HOC exploratory comparison, V3 guard was designed after inspecting these same 22 test cases; not independent validation',
        'ground_truth':'Researcher-coarsened source descriptions, not independently verified; broad build_failure is only investigation hint',
        'fixed_thresholds':{'similarity':0.52,'margin':0.025},
        'memory':'96 synthetic fixture-derived cases; not independent production incident memory',
        'setup_note':'V2 and V3 share ONE indexed retriever per engine in this run; amortized setup is shown for each method for comparison, not paid twice in actual combined processing.',
        'results':results}
    (a.output_dir/'metrics_v3.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
    lines=['# PatchRail AI V3 — post-hoc safety evaluation','',
       '**Not independent confirmation of accuracy improvement.** Evidence guard rules were designed after V2 error analysis of this same 22-log set. Labels are provisional.','',
       '| Method | Correct / 22 | Correct % | Named coverage | Wrong named | Mean time per log incl. amortized setup |',
       '|---|---:|---:|---:|---:|---:|']
    for r in results:lines.append(f'| {r["method"]} | {r["correct"]}/{r["n"]} | {r["correct_pct"]}% | {r["coverage_pct"]}% | {r["wrong_named"]} | {r["amortized_setup_seconds"]} s |')
    lines+=['','New AI categories and broad build hints are investigation suggestions requiring human verification, NOT confirmed root causes.','',
            'Evaluation scoring of broad labels may disagree with original PatchRail maintainer acceptance of abstentions.','',
            'Next step: separately collect and independently label new logs, pre-register rules, then measure true hold-out performance.']
    (a.output_dir/'REPORT_V3.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    try:
        import matplotlib
        matplotlib.use('Agg');import matplotlib.pyplot as plt
        for field,name,ylabel in [('correct_pct','correctness_v3.png','Correctness %'),('coverage_pct','coverage_v3.png','Named coverage %'),('wrong_named','wrong_suggestions_v3.png','Wrong named diagnoses'),('amortized_setup_seconds','runtime_v3.png','Seconds/log')]:
            fig,ax=plt.subplots(figsize=(9,4.7)); vals=[r[field] for r in results];names=[r['method'] for r in results]
            bars=ax.bar(names,vals)
            for b,v in zip(bars,vals):ax.text(b.get_x()+b.get_width()/2,b.get_height(),str(v),ha='center',va='bottom')
            ax.set_ylim(0,max(vals+[1])*1.22);ax.set_title(field.replace('_',' ').title());ax.set_ylabel(ylabel)
            fig.tight_layout();fig.savefig(a.output_dir/name,dpi=160);plt.close(fig)
    except ImportError:
        print('matplotlib not installed: charts skipped')
    print('\n'.join(lines));print('Reports:',a.output_dir.resolve())
if __name__=='__main__':main()

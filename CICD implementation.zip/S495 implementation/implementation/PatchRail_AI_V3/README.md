# PatchRail + MiniLM Version 3: Evidence-checked CI failure investigation

This is a **reproducible, read-only research prototype** that uses your original PatchRail source unchanged. It adds two features to the Version 2 similarity extension:

1. **Category-specific evidence gates:** A new AI suggestion is compared against real error lines, not merely the similarity score. For example, a cache warning or a Flutter lint error is not evidence of a failed release operation.
2. **Safe generalisation of an unsupported specific tool:** If the AI guesses `docker_build_failure` but the log shows an actual failed **non-Docker** build, Version 3 may suggest a broad `build_failure` **investigation hint**, expressly not a Docker root cause. When the evidence is weak it abstains.

Original named PatchRail decisions are **never overridden** by V3. AI suggestions are **never confirmed root causes** and cannot make tests pass, approve a deployment, retry builds or roll back systems. The 96 memory items are **PatchRail-authored synthetic fixtures**, not real production incidents. Similarity scores are **not probabilities**.

## Quick start (your Windows 10 computer)

Keep the original PatchRail folder extracted at:

`C:\Users\Administrator\Downloads\patchrail-main\patchrail-main`

Extract this V3 ZIP. In the extracted `PatchRail_AI_V3` folder, double-click **`RUN_WINDOWS_V3.cmd`**. This runs 16 unit tests and then the PatchRail / TF-IDF V2-V3 / MiniLM V2-V3 comparison.

If you prefer CMD commands, open CMD in this project's folder:

```bat
python -m pip install -r requirements-v2.txt
python -m pip install -r requirements-minilm.txt
python -m pytest -q tests
python evaluate_v3.py --patchrail-root "C:\Users\Administrator\Downloads\patchrail-main\patchrail-main" --engines tfidf minilm --output-dir results_windows_v3
```

**Model weights:** MiniLM may download on its first run (you have already cached it on this computer). If MiniLM cannot load, use `--engines tfidf` for an offline evaluation and report that limitation accurately.

The generated folder `results_windows_v3` contains:

- `REPORT_V3.md`: five-method comparative results.
- `metrics_v3.json`: numeric metrics and warnings.
- `case_results_v3.csv`: log-by-log baseline/V2/V3 predictions and evidence status.
- `correctness_v3.png`, `coverage_v3.png`, `wrong_suggestions_v3.png`, `runtime_v3.png`: measured graphs (not illustrative artwork).

Open in Windows CMD:

```bat
notepad results_windows_v3\REPORT_V3.md
notepad results_windows_v3\metrics_v3.json
start results_windows_v3\correctness_v3.png
start results_windows_v3\coverage_v3.png
start results_windows_v3\wrong_suggestions_v3.png
start results_windows_v3\runtime_v3.png
```

## Live integration on one real-world log

```bat
python integrate_v3.py --patchrail-root "C:\Users\Administrator\Downloads\patchrail-main\patchrail-main" --log "C:\Users\Administrator\Downloads\patchrail-main\patchrail-main\examples\real-world\cabal-29562439929-excerpt.log" --engine minilm --out-dir reports_cabal_v3
notepad reports_cabal_v3\v3_report.md
```

Try Pandas (warning-only cache output) as a contrasting safety check:

```bat
python integrate_v3.py --patchrail-root "C:\Users\Administrator\Downloads\patchrail-main\patchrail-main" --log "C:\Users\Administrator\Downloads\patchrail-main\patchrail-main\examples\real-world\pandas-29342614636.log" --engine minilm --out-dir reports_pandas_v3
notepad reports_pandas_v3\v3_report.md
```

## Preview saved Windows MiniLM V2 results without rerunning the model

For an instant **post-hoc preview**, run this on the *already generated* Windows V2 CSV:

```bat
python preview_saved_v2.py --patchrail-root "C:\Users\Administrator\Downloads\patchrail-main\patchrail-main" --v2-cases "C:\Users\Administrator\Downloads\PatchRail_AI_V2_Improved_Evaluation\PatchRail_AI_V2\results_windows_v2\case_results.csv" --output-dir posthoc_preview_windows
```

**DO NOT present preview numbers as an independent experiment.** It rechecks previously observed test data with rules derived after examining those cases. The full `evaluate_v3.py` command runs V3 inference fresh on your computer; **that remains post-hoc on these same 22 logs**.

## Source files

- `evidence_gate_v3.py` — evidence rules and warnings exclusion.
- `triage_v3.py` — combines existing `Retriever` with evidence gate.
- `integrate_v3.py` — single-log PatchRail + AI demonstration.
- `evaluate_v3.py` — case-level comparison and four charts.
- `preview_saved_v2.py` — saved-predictions sensitivity analysis.
- `tests/test_v3.py` — 16 unit tests, including warnings, unsupported guesses, baseline retention.
- `enhanced_triage.py`, `ai_triage.py`, and `data/fixture_memory.jsonl` — reproducibility from V2.
- `data/ground_truth.json` — 22 provisional broad labels; independent audit required.
- `data/independent_label_review_template.csv` — reviewer form for later independent validation.

## Scientific limitations

- The 22 evaluation logs and error descriptions have already informed the V3 safety rules. **These same logs cannot establish unbiased improvement**. A new untouched dataset and independent labels are required for that claim.
- PatchRail's maintainer accepts some deliberate unknown/broad categories that the study's provisional broad labels count as incorrect. Report both taxonomies rather than calling one a definitive truth.
- We report **named investigation suggestions**, not proven root causes or improved DORA delivery metrics.
- A family hint like `build_failure` does not prove the specific failure technology. The exact cause requires human verification.
- MiniLM setup time and model load vary by machine; the script notes when setup is amortised.

The original PatchRail code is not bundled, only its independent V3 extension and the original licensing notice, to respect attribution. The original source must be supplied separately.

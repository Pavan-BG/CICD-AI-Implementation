# V3 post-hoc saved prediction preview

**DO NOT CITE AS INDEPENDENT PERFORMANCE.** These are V2 predictions modified after examining the same test logs.

| Method | V2 correct | V3 preview correct | V2 named | V3 preview named | V2 wrong named | V3 preview wrong named |
|---|---:|---:|---:|---:|---:|---:|
| tfidf_v2 | 9 | 9 | 13 | 12 | 5 | 4 |
| minilm_v2 | 9 | 10 | 14 | 13 | 5 | 4 |

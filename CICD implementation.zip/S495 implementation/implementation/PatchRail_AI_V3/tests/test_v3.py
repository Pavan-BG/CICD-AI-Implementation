"""Unit/synthetic evidence fixtures. Not an independent real-world evaluation."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from evidence_gate_v3 import check_evidence
from enhanced_triage import Retriever
from triage_v3 import triage_v3

MEM=[
 {'id':'a','category':'artifact_or_cache_failure','log':'Error: Cache upload failed because tar archive is corrupt','advice':'Review cache'},
 {'id':'b','category':'docker_build_failure','log':'docker build failed: ERROR: failed to solve stage','advice':'Review Docker'},
 {'id':'c','category':'release_publish_failure','log':'npm publish failed with 403 forbidden','advice':'Review publish'},
]

def test_no_failed_operation_cache():
    r=check_evidence('artifact_or_cache_failure','Cache installed successfully\nPackages listed\n')
    assert r.decision=='unsupported'

def test_explicit_cache_failure():
    r=check_evidence('artifact_or_cache_failure','Error: cache restore failed due to missing key')
    assert r.decision=='supported_specific'

def test_release_cannot_be_inferred_from_lint():
    r=check_evidence('release_publish_failure','flutter analyze\nerror - unnecessary_unawaited\n3 issues found')
    assert r.decision=='unsupported'

def test_release_failed_actual_operation():
    r=check_evidence('release_publish_failure','npm publish failed: 403 forbidden')
    assert r.decision=='supported_specific'

def test_docker_success_then_test_error_not_specific():
    r=check_evidence('docker_build_failure','docker build succeeded\nSome unrelated data\npytest failed: AssertionError')
    assert r.decision=='unsupported'

def test_docker_real_error():
    r=check_evidence('docker_build_failure','ERROR: docker build failed to solve: exec /bin/bash not found')
    assert r.decision=='supported_specific'

def test_cabal_failed_build_is_not_docker_root_cause():
    r=check_evidence('docker_build_failure',"*** Exception: Command /runner/cabal v2-build --builddir dist failed.")
    assert r.decision=='broad_build_only'
    assert r.category=='build_failure'

def test_unknown_subtype_rejects_when_evidence_absent():
    r=check_evidence('infrastructure_transient','Error: Failed to execute unrelated function')
    assert r.decision=='unsupported'

def test_v3_preserves_baseline_even_low_confidence():
    ret=Retriever(MEM,'tfidf')
    r=triage_v3('Error: Cache upload failed', 'python_test_failure',0.25,ret)
    assert r['status']=='baseline_kept'
    assert r['predicted_category']=='python_test_failure'
    assert not r['human_review_required']
    assert not r['changes_ci_status']

def test_v3_rejects_unknown_ai_candidate_without_failed_operation():
    ret=Retriever(MEM,'tfidf')
    r=triage_v3('Normal package downloads, no failures', 'unknown',0.15,ret,0.0,0.0)
    assert r['predicted_category']=='unknown'
    assert not r['changes_ci_status']

def test_v3_specific_suggestion_always_requires_review():
    ret=Retriever(MEM,'tfidf')
    r=triage_v3('Error: Cache upload failed because tar archive is corrupt','unknown',0.15,ret,0,0)
    assert r['status']=='ai_evidence_supported_review_required'
    assert r['human_review_required'] and not r['ai_confirmed_root_cause']
    assert r['predicted_category']=='artifact_or_cache_failure'

def test_v3_broad_hint_not_tool_claim():
    ret=Retriever(MEM,'tfidf')
    r=triage_v3('*** Exception: Command cabal v2-build --builddir dist failed.','unknown',0.15,ret,0,0)
    assert r['status']!='baseline_kept'
    assert not r['changes_ci_status']

def test_warning_only_cache_save_does_not_confirm_ci_failure():
    txt = '##[warning]Failed to save: Unable to reserve cache key.\nSaved cache with ID -1\nNormal package install complete'
    r=check_evidence('artifact_or_cache_failure',txt)
    assert r.decision=='unsupported'

def test_cache_error_after_earlier_warning_still_can_be_verified():
    txt='##[warning]Failed to save: collision\nERROR: cache artifact upload failed, exiting'
    r=check_evidence('artifact_or_cache_failure',txt)
    assert r.decision=='supported_specific'

def test_unrelated_error_next_to_successful_cache_not_cache_failure():
    r=check_evidence('artifact_or_cache_failure','Saved cache to disk\nError: application tests failed')
    assert r.decision=='unsupported'

def test_unrelated_error_next_to_successful_release_not_publish_failure():
    r=check_evidence('release_publish_failure','Published release successfully\nError: unit test failed')
    assert r.decision=='unsupported'

"""Reproducible held-out diagnostic comparison (research prototype, not production validation).

Four/five rows per test case: unchanged PatchRail, V1 TF-IDF, V2 TF-IDF,
plus optional V1 and V2 MiniLM. All 22 held-out real-world cases kept intact.
Expanded V2 memory is derived from *other synthetic PatchRail fixtures*, never
from those 22 real-world cases; do not describe it as real-world history.
"""
from __future__ import annotations
import argparse
import csv
import json
import os
import sys
import time
from collections import Counter
from pathlib import Path
from statistics import median

HERE = Path(__file__).resolve().parent
import ai_triage
from enhanced_triage import Retriever, DEFAULT_SIMILARITY, DEFAULT_MARGIN
from evaluate import coarse


def calculate(rows: list[dict], method: str, setup_seconds: float) -> dict:
    part = [r for r in rows if r['method'] == method]
    n = len(part)
    correct = sum(r['correct'] for r in part)
    suggested = [r for r in part if r['predicted_coarse'] != 'insufficient_evidence']
    true_suggestions = sum(r['correct'] for r in suggested)
    wrong = len(suggested) - true_suggestions
    new_errors = sum(r['baseline_correct'] and not r['correct'] for r in part)
    resolved = sum(not r['baseline_correct'] and r['correct'] for r in part)
    false_unknown = sum(r['truth'] == 'insufficient_evidence' and r['predicted_coarse'] != 'insufficient_evidence' for r in part)
    timings = [r['seconds_inference'] for r in part]
    return {
        'method':method,'cases':n,'correct':correct,'correct_pct':round(correct/n*100,2),
        'suggestions':len(suggested),'coverage_pct':round(len(suggested)/n*100,2),
        'correct_named_suggestions':true_suggestions, 'wrong_named_suggestions':wrong,
        'precision_pct':round(100*true_suggestions/len(suggested),2) if suggested else None,
        'previously_wrong_cases_corrected':resolved,'previously_correct_cases_harmed':new_errors,
        'false_named_on_insufficient_evidence':false_unknown,
        'setup_seconds':round(setup_seconds,3),
        'mean_inference_seconds':round(sum(timings)/n,4),
        'median_inference_seconds':round(median(timings),4),
        'mean_amortized_seconds':round(sum(timings)/n+setup_seconds/n,4),
        'status_counts':dict(Counter(r['status'] for r in part)),
    }


def plot(summaries: list[dict], out: Path):
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        print('matplotlib missing: CSV/JSON created; charts skipped')
        return
    names = [r['method'].replace('patchrail_','') for r in summaries]
    fields = [
        ('correct_pct','Correct broad classification, including abstention (%)','classification_comparison.png','%'),
        ('coverage_pct','Named diagnosis coverage (%)','coverage_comparison.png','%'),
        ('mean_amortized_seconds','Processing time per log including amortized setup (s)','runtime_comparison.png','Seconds'),
        ('wrong_named_suggestions','Incorrect named diagnosis count','wrong_suggestions_comparison.png','Cases'),
    ]
    for field, title, fn, ylabel in fields:
        values = [r[field] for r in summaries]
        fig, ax=plt.subplots(figsize=(10,5.2))
        rects=ax.bar(names,values)
        for bar, v in zip(rects,values):
            ax.text(bar.get_x()+bar.get_width()/2,bar.get_height(),str(v),ha='center',va='bottom',fontsize=10)
        ax.set_ylim(0,max(values or [1])*1.20 if max(values or [0]) else 1)
        ax.set_title(title); ax.set_ylabel(ylabel)
        fig.tight_layout(); fig.savefig(out/fn,dpi=170); plt.close(fig)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--patchrail-root',type=Path,required=True)
    p.add_argument('--engines',nargs='+',choices=['tfidf','minilm'],default=['tfidf','minilm'])
    p.add_argument('--output-dir',type=Path,default=Path('results_v2'))
    p.add_argument('--v1-memory',type=Path,default=HERE/'data'/'illustrative_incidents.jsonl')
    p.add_argument('--v2-memory',type=Path,default=HERE/'data'/'fixture_memory.jsonl')
    p.add_argument('--similarity-threshold',type=float,default=DEFAULT_SIMILARITY)
    p.add_argument('--margin-threshold',type=float,default=DEFAULT_MARGIN)
    args=p.parse_args()
    root=args.patchrail_root.resolve()
    if not (root/'src'/'patchrail').is_dir() or not (root/'examples'/'real-world').is_dir():
        p.error('The PatchRail source root must contain src/patchrail and examples/real-world')
    # Ensure held-out files do not overlap fixture memory's source locations
    labels = json.loads((HERE/'data'/'ground_truth.json').read_text(encoding='utf-8'))['cases']
    v1_memory = ai_triage.load_memory(args.v1_memory)
    v2_memory = ai_triage.load_memory(args.v2_memory)
    test_fns = {x['file'] for x in labels}
    overlap = [x['source_file'] for x in v2_memory if Path(x.get('source_file','')).name in test_fns]
    if overlap: raise ValueError(f'Data contamination: memory source overlaps held-out logs: {overlap}')
    sys.path.insert(0,str(root/'src'))
    from patchrail.ci.classify import classify_ci_log,redact_ci_log
    from patchrail import __version__ as patchrail_version
    ai_triage.BASELINE_THRESHOLD = 0.35
    args.output_dir.mkdir(parents=True,exist_ok=True)
    retrievers={}; setup={}
    # Index once. Pretrained MiniLM loaded once for V2; V1 loads repeatedly (as in old program).
    for engine in args.engines:
        t0 = time.perf_counter()
        retrievers[engine]=Retriever(v2_memory, engine)
        setup[engine]=time.perf_counter()-t0
        print(f'V2 {engine}: {len(v2_memory)} memory entries indexed in {setup[engine]:.2f}s',flush=True)
    rows=[]
    methods=['patchrail'] + [f'{e}_v1' for e in args.engines] + [f'{e}_v2' for e in args.engines]
    for i,item in enumerate(labels,1):
        path=root/'examples'/'real-world'/item['file']
        if not path.is_file(): raise FileNotFoundError(path)
        raw = path.read_text(encoding='utf-8',errors='replace')
        t0 = time.perf_counter(); base = classify_ci_log(raw); tbase=time.perf_counter()-t0
        base_class=base.get('failure_class','unknown') or 'unknown'
        confidence=float(base.get('confidence') or 0)
        original=coarse(base_class)
        clean=redact_ci_log(raw)['text']
        baseline_correct = int(original==item['truth'])
        def add(method, outcome, status, seconds, sim=None, margin=None):
            pred=coarse(outcome)
            rows.append({'file':item['file'],'truth':item['truth'],'truth_description':item['reason'],
                         'method':method,'raw_baseline_class':base_class,'baseline_confidence':confidence,
                         'predicted_class':outcome,'predicted_coarse':pred,'correct':int(pred==item['truth']),
                         'baseline_correct':baseline_correct,'status':status,
                         'seconds_inference':round(seconds,5),'similarity':sim,'margin':margin})
        add('patchrail',base_class,'baseline',tbase)
        for engine in args.engines:
            t=time.perf_counter()
            v1=ai_triage.analyze(clean,v1_memory,base_class,confidence,engine=engine,
                                  similarity_threshold=args.similarity_threshold,
                                  margin_threshold=args.margin_threshold)
            add(f'{engine}_v1',v1['predicted_category'],v1['status'],tbase+time.perf_counter()-t,
                v1.get('similarity'),v1.get('similarity_margin'))
            t=time.perf_counter()
            v2=retrievers[engine].predict(clean,base_class,confidence,
                                        similarity_threshold=args.similarity_threshold,
                                        margin_threshold=args.margin_threshold)
            add(f'{engine}_v2',v2['predicted_category'],v2['status'],tbase+time.perf_counter()-t,
                v2.get('similarity'),v2.get('similarity_margin'))
        print(f'[{i:02}/{len(labels)}] {item["file"]}: truth={item["truth"]}, PatchRail={original}',flush=True)
    with (args.output_dir/'case_results.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    summaries=[calculate(rows,m,setup.get(m.replace('_v2',''),0) if m.endswith('_v2') else 0) for m in methods]
    payload={'experiment':'V2 prototype comparison, not a validated performance claim',
        'original_patchrail_version':patchrail_version,'case_count':len(labels),
        'test_data':'22 public real-world logs; labels coarsened by researcher from maintainer notes',
        'v1_memory':'12 illustrative authored examples',
        'v2_memory':f'{len(v2_memory)} fixture-derived synthetic PatchRail cases (NOT independent real incidents)',
        'overlap_check':'no same test log filenames in fixture memory',
        'thresholds':{'similarity':args.similarity_threshold,'margin':args.margin_threshold},
        'runtime_note':'V2 setup includes memory indexing and model initialization (amortized across cases); V1 repeatedly loads model; timing depends on host and disk cache.',
        'methods':summaries}
    (args.output_dir/'metrics.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    lines=['# PatchRail AI V2 — comparative evaluation','',
        '**Preliminary results only.** 22 public real-world logs. Labels are researcher-mapped from existing maintainer descriptions and are not independently audited.','',
        '**The expanded memory is built from PatchRail authored synthetic fixtures, not production incidents.** It excludes the 22 held-out test files. Do not describe it as an independently trained model.','',
        '| Method | Correct /22 | Correct % | Coverage % | Incorrect named | Time/log incl. setup (s) |',
        '|---|---:|---:|---:|---:|---:|']
    for r in summaries:
        lines.append(f'| {r["method"]} | {r["correct"]}/{r["cases"]} | {r["correct_pct"]} | {r["coverage_pct"]} | {r["wrong_named_suggestions"]} | {r["mean_amortized_seconds"]} |')
    lines += ['', 'Accuracy includes appropriate abstentions as correct only for the single insufficient-evidence truth case. Higher coverage is not always better.','',
        'V2 has two targeted technical changes: (1) diagnostic-line extraction and expanded fixture-derived memory, (2) cached memory embeddings and competing-category confidence margin. **Neither improvement should be claimed without these comparisons.**',
        '', 'Original PatchRail is unmodified. The AI fallback does not approve releases, retry builds, or change CI status.',
        '', 'Independent root-cause annotation, better memory sources, threshold validation on separate data, and execution on a live CI workflow remain for future work.',
        '', 'Generated files: case_results.csv, metrics.json, REPORT.md, and four comparison PNG graphs.']
    (args.output_dir/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    plot(summaries,args.output_dir)
    print('\n'.join(lines)); print('\nSaved to:',args.output_dir.resolve())

if __name__=='__main__': main()

"""Read-only reproducible comparison: original PatchRail vs TF-IDF vs MiniLM.
Run against the original PatchRail archive's 22 documented real CI logs.
Ground-truth labels are author-described coarse failure types, not independent adjudication.
"""
from __future__ import annotations
import argparse
import csv
import json
import sys
import time
from collections import Counter
from pathlib import Path
import ai_triage

HERE = Path(__file__).resolve().parent
LABELS = HERE / 'data' / 'ground_truth.json'
MEMORY = HERE / 'data' / 'illustrative_incidents.jsonl'

# Coarse outcomes are an analysis convenience; a classifier class is not the exact root cause.
def coarse(label):
    s = (label or 'unknown').lower()
    if s in ('unknown', '', 'manual_review'): return 'insufficient_evidence'
    if s in ('test_assertion', 'python_test_failure', 'go_test_failure', 'node_test_failure', 'rust_test_failure', 'elixir_mix_failure', 'browser_test_failure'):
        return 'test_failure'
    if s in ('java_build_failure','dotnet_build_failure','cpp_build_failure','xcode_build_failure','docker_build_failure','docs_build_failure','php_composer_failure'):
        return 'build_failure'
    if s in ('javascript_lint','go_lint','shell_lint','typescript_typecheck'): return 'lint_failure'
    if s in ('dependency_resolution','python_dependency_resolution','node_dependency_install','ruby_bundle_failure'):
        return 'dependency_failure'
    if s == 'code_coverage_threshold': return 'coverage_failure'
    if s in ('infrastructure_transient','network_transient_failure','runner_resource_exhaustion','ci_job_timeout','artifact_or_cache_failure'):
        return 'infrastructure_failure'
    if s in ('workflow_configuration','github_actions_workflow','git_checkout_failure','git_merge_conflict','release_publish_failure'):
        return 'workflow_failure'
    return 'other_failure'


def summarize(rows, engine):
    subset = [r for r in rows if r['engine'] == engine]
    n = len(subset)
    covered = [r for r in subset if r['suggested_category'] != 'insufficient_evidence']
    correct = sum(r['correct'] for r in subset)
    wrong_suggestions = [r for r in covered if not r['correct']]
    unknown_truth = [r for r in subset if r['truth'] == 'insufficient_evidence']
    unsafe_unknown = [r for r in unknown_truth if r['suggested_category'] != 'insufficient_evidence']
    return {
        'method':engine, 'cases':n,'correct_cases':correct,
        'overall_correct_pct':round(100*correct/n, 2) if n else None,
        'suggested_cases':len(covered), 'coverage_pct':round(100*len(covered)/n,2) if n else None,
        'correct_suggestions':len(covered)-len(wrong_suggestions),
        'suggestion_precision_pct':round(100*(len(covered)-len(wrong_suggestions))/len(covered),2) if covered else None,
        'incorrect_suggestions':len(wrong_suggestions),
        'unknown_truth_false_suggestions':len(unsafe_unknown),
        'mean_runtime_seconds':round(sum(r['seconds'] for r in subset)/n,4) if n else None,
        'median_runtime_seconds':round(sorted(r['seconds'] for r in subset)[n//2],4) if n else None,
        'status_counts':dict(Counter(r['status'] for r in subset)),
    }


def plot_summary(summaries, output):
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        return 'matplotlib not installed, graph skipped'
    methods=[s['method'] for s in summaries]
    for field,title,filename in [
        ('overall_correct_pct','Correct classification, including abstentions (%)','accuracy_comparison.png'),
        ('coverage_pct','Diagnosis coverage (%)','coverage_comparison.png'),
        ('mean_runtime_seconds','Average processing time per log (seconds)','runtime_comparison.png')]:
        vals=[s[field] for s in summaries]
        fig,ax=plt.subplots(figsize=(7,4))
        ax.bar(methods,vals)
        ax.set_title(title)
        ax.set_ylabel('%' if field!='mean_runtime_seconds' else 'Seconds')
        ax.set_ylim(bottom=0)
        for i,v in enumerate(vals): ax.text(i,v, str(v),ha='center',va='bottom')
        fig.tight_layout()
        fig.savefig(output/filename,dpi=170)
        plt.close(fig)
    return None


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--patchrail-root',type=Path,required=True,help='path containing src/patchrail and examples/real-world')
    ap.add_argument('--engines', nargs='+',choices=['tfidf','minilm'],default=['tfidf','minilm'])
    ap.add_argument('--output-dir',type=Path,default=HERE/'results')
    ap.add_argument('--memory',type=Path,default=MEMORY)
    ap.add_argument('--similarity-threshold',type=float,default=ai_triage.SIMILARITY_THRESHOLD)
    ap.add_argument('--margin-threshold',type=float,default=ai_triage.MARGIN_THRESHOLD)
    args=ap.parse_args()
    root=args.patchrail_root.resolve()
    src=root/'src'
    logs=root/'examples'/'real-world'
    if not src.is_dir() or not logs.is_dir(): ap.error('PatchRail root must contain src/ and examples/real-world/')
    sys.path.insert(0,str(src))
    from patchrail.ci.classify import classify_ci_log,redact_ci_log
    from patchrail import __version__ as patchrail_version
    labels=json.loads(LABELS.read_text(encoding='utf-8'))['cases']
    memory=ai_triage.load_memory(args.memory)
    # Match the integrated adapter: PatchRail diagnoses are retained at >=0.35.
    ai_triage.BASELINE_THRESHOLD = 0.35
    args.output_dir.mkdir(parents=True,exist_ok=True)
    # Memory entries are hand-written demonstration cases and have NO overlap with real-world log filenames.
    rows=[]
    for index,case in enumerate(labels,1):
        path=logs/case['file']
        if not path.exists(): raise FileNotFoundError(path)
        raw=path.read_text(encoding='utf-8',errors='replace')
        t0=time.perf_counter()
        baseline=classify_ci_log(raw)
        elapsed=time.perf_counter()-t0
        raw_class=baseline.get('failure_class','unknown')
        conf=float(baseline.get('confidence') or 0)
        orig=coarse(raw_class)
        def row(method,category,status,seconds,raw_cat='',similarity=None,margin=None):
            return {'case_id':index,'log':case['file'],'truth':case['truth'],'truth_reason':case['reason'],
                    'engine':method,'baseline_raw_class':raw_class,'baseline_confidence':conf,
                    'suggested_raw_class':raw_cat or raw_class,'suggested_category':category,'status':status,
                    'correct':int(category==case['truth']),'seconds':round(seconds,5),
                    'similarity':similarity,'similarity_margin':margin}
        rows.append(row('patchrail',orig,'baseline',elapsed))
        clean=redact_ci_log(raw)['text']
        for engine in args.engines:
            t1=time.perf_counter()
            # Adapter invokes only for unknown/low-confidence results, but above is always timed.
            result=ai_triage.analyze(clean,memory,raw_class,conf,engine=engine,
                similarity_threshold=args.similarity_threshold,margin_threshold=args.margin_threshold)
            method_seconds=elapsed+(time.perf_counter()-t1)
            pred=coarse(result['predicted_category'])
            rows.append(row(engine,pred,result['status'],method_seconds,result['predicted_category'],
                            result.get('similarity'),result.get('similarity_margin')))
        print(f'[{index:02d}/{len(labels)}] {case["file"]}: truth={case["truth"]}, baseline={orig}',flush=True)
    csv_file=args.output_dir/'case_results.csv'
    with csv_file.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    summaries=[summarize(rows,engine) for engine in ['patchrail',*args.engines]]
    payload={'status':'experiment_completed','patchrail_version':patchrail_version,
        'dataset':'22 documented public failed CI run logs in PatchRail archive',
        'memory':'12 illustrative incidents; not learned from these logs',
        'labels':'Researcher-mapped coarse types based on PatchRail author explanations; not independently reviewed',
        'thresholds':{'similarity':args.similarity_threshold,'margin':args.margin_threshold},
        'engines_executed':['patchrail',*args.engines],'summary':summaries}
    (args.output_dir/'metrics.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    plot_summary(summaries,args.output_dir)
    lines=['# CI failure diagnosis comparative evaluation','',
        '**Scope:** 22 public real-world CI logs already provided in the PatchRail source repository. The two additional logs lacking documented labels were excluded.','',
        '**Ground truth:** researcher-coarsened labels derived from the source maintainer descriptions, not independently verified. Not publication-grade without independent review.','',
        '**Memory:** 12 illustrative examples; no evaluation log copied into memory. Same memory and thresholds for all fallback engines.','',
        '| Method | Correct / 22 | Correct (%) | Coverage (%) | Wrong suggestions | Mean seconds/log |',
        '|---|---:|---:|---:|---:|---:|']
    for s in summaries:
        lines.append(f"| {s['method']} | {s['correct_cases']}/{s['cases']} | {s['overall_correct_pct']} | {s['coverage_pct']} | {s['incorrect_suggestions']} | {s['mean_runtime_seconds']} |")
    lines += ['','Correct (%) counts unknown as correct only where the source says no usable error evidence exists. A suggestion is **not automatically accepted**: all AI suggestions require human review.','',
              'Important limitations: no independent annotators, no trained/tuned threshold validation, small memory, sample contains PatchRail development cases, and processing overhead depends on machine/model caching. No proven impact on production DORA metrics.','',
              'Charts generated: accuracy_comparison.png, coverage_comparison.png, runtime_comparison.png.']
    (args.output_dir/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines[:len(summaries)+8]))
    print(f'\nReports: {args.output_dir.resolve()}')

if __name__=='__main__': main()

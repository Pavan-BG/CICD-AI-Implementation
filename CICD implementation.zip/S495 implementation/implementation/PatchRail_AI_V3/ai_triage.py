"""Read-only confidence-gated semantic fallback for a CI failure triage baseline.

Original demonstration adapter intended to run AFTER an existing PatchRail GitHub Action.
No deployment, rollback, retries, permission escalation, or test-status changes.
"""
from __future__ import annotations

import argparse
import json
import os
import re
from pathlib import Path
from typing import Any

BASELINE_THRESHOLD = 0.70
SIMILARITY_THRESHOLD = 0.52  # Demo only: tune on a *separate* validation set.
MARGIN_THRESHOLD = 0.025     # Demo only: tune before held-out testing.

REDACTIONS = [
    (r"(?i)(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{20,}", "[REDACTED_GITHUB_TOKEN]"),
    (r"AKIA[0-9A-Z]{16}", "[REDACTED_AWS_KEY]"),
    (r"(?i)\b(?:password|api[_-]?key|access[_-]?token|secret)\s*[:=]\s*['\"]?\S+", "[REDACTED_SECRET]"),
    (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", "[REDACTED_EMAIL]"),
]

CUES = ("error", "failed", "exception", "cannot", "could not", "timeout", "timed out", "assert", "not found", "no module", "denied", "resolution", "exhaust", "refused")


def redact(text: str) -> str:
    """Basic local redaction, not a substitute for organisation-grade controls."""
    for pattern, substitution in REDACTIONS:
        text = re.sub(pattern, substitution, text)
    return text


def excerpt(text: str, max_lines: int = 12) -> str:
    """Keep diagnostic lines; control context size for short-text models."""
    lines = [x.strip()[:320] for x in text.splitlines() if x.strip()]
    salient = [line for line in lines if any(cue in line.lower() for cue in CUES)]
    selected = (salient[-max_lines:] if salient else lines[-max_lines:])
    return "\n".join(selected)[:1600]


def load_memory(path: Path) -> list[dict[str, Any]]:
    incidents = []
    for n, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not raw.strip():
            continue
        item = json.loads(raw)
        for field in ("id", "category", "log", "advice"):
            if not isinstance(item.get(field), str) or not item[field].strip():
                raise ValueError(f"Memory line {n}: missing {field}")
        incidents.append(item)
    if not incidents:
        raise ValueError("Incident memory is empty")
    return incidents


def rank_matches(query: str, incidents: list[dict[str, Any]], engine: str) -> list[tuple[float, dict[str, Any]]]:
    """Similarity, NOT calibrated P(root cause)."""
    texts = [excerpt(redact(it["log"])) for it in incidents]
    if engine == "minilm":
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as err:
            raise SystemExit("Missing model dependency: pip install -r requirements-hf.txt") from err
        model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        vectors = model.encode(texts + [query], normalize_embeddings=True)
        scores = vectors[:-1] @ vectors[-1]
    elif engine == "tfidf":
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity
        corpus = texts + [query]
        vectors = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5)).fit_transform(corpus)
        scores = cosine_similarity(vectors[:-1], vectors[-1]).ravel()
    else:
        raise ValueError(f"Unknown engine: {engine}")
    return sorted([(float(s), incident) for s, incident in zip(scores, incidents)],
                  key=lambda pair: pair[0], reverse=True)


def analyze(log: str, incidents: list[dict[str, Any]], baseline_class: str,
            baseline_confidence: float, engine: str = "minilm",
            force_ai: bool = False, similarity_threshold: float = SIMILARITY_THRESHOLD,
            margin_threshold: float = MARGIN_THRESHOLD) -> dict[str, Any]:
    clean_excerpt = excerpt(redact(log))
    baseline_ok = (baseline_class.strip().lower() not in ("", "unknown")
                   and baseline_confidence >= BASELINE_THRESHOLD)
    report: dict[str, Any] = {
        "baseline_class": baseline_class or "unknown",
        "baseline_confidence": baseline_confidence,
        "engine": engine,
        "evidence_excerpt": clean_excerpt,
        "status": "baseline_kept" if baseline_ok and not force_ai else "manual_review",
        "predicted_category": baseline_class if baseline_ok and not force_ai else "unknown",
        "suggested_action": "Review the failing pipeline manually; do not override the failed CI status.",
        "similarity": None,
        "matched_incident_id": None,
        "auto_retry": False,
        "changes_ci_status": False,
    }
    if baseline_ok and not force_ai:
        report["suggested_action"] = "Use existing PatchRail diagnosis; review its evidence and remediation guide."
        return report
    if not clean_excerpt:
        return report
    ranked = rank_matches(clean_excerpt, incidents, engine)
    top_score, top = ranked[0]
    second_score = ranked[1][0] if len(ranked) > 1 else 0.0
    report["similarity"] = round(top_score, 4)
    report["matched_incident_id"] = top["id"]
    report["similarity_margin"] = round(top_score - second_score, 4)
    if top_score >= similarity_threshold and (top_score - second_score) >= margin_threshold:
        report["status"] = "ai_suggestion_review_required"
        report["predicted_category"] = top["category"]
        report["suggested_action"] = top["advice"]
    return report


def to_markdown(report: dict[str, Any]) -> str:
    lines = ["# CI failure triage report (read-only)",
             f"- Baseline: `{report['baseline_class']}`; score `{report['baseline_confidence']:.3f}`",
             f"- Status: `{report['status']}`",
             f"- Suggested category: `{report['predicted_category']}`",
             f"- AI engine: `{report['engine']}`"]
    if report["similarity"] is not None:
        lines.extend([f"- Nearest historical case: `{report['matched_incident_id']}`",
                      f"- Similarity (not probability): `{report['similarity']:.3f}`",
                      f"- Top-two similarity gap: `{report['similarity_margin']:.3f}`"])
    lines.extend(["", "## Recommended investigation", report["suggested_action"],
                  "", "## Selected failure evidence", "```text", report["evidence_excerpt"], "```",
                  "", "**Safety:** Test and release failure statuses are preserved. "
                  "No automatic retry, approval, fix or rollback is performed. "
                  "Unknown and uncertain cases require human inspection."])
    return "\n".join(lines) + "\n"


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--log", type=Path, required=True)
    p.add_argument("--memory", type=Path, default=Path("data/illustrative_incidents.jsonl"))
    p.add_argument("--baseline-class", default=os.environ.get("PATCHRAIL_CLASS", "unknown"))
    p.add_argument("--baseline-confidence", default=os.environ.get("PATCHRAIL_CONFIDENCE", "0"))
    p.add_argument("--engine", choices=["minilm", "tfidf"], default="minilm")
    p.add_argument("--force-ai", action="store_true", help="Diagnostic demonstration only")
    p.add_argument("--report", type=Path, default=Path("triage_report.md"))
    p.add_argument("--json", type=Path, default=Path("triage_report.json"))
    args = p.parse_args()
    try:
        conf = float(args.baseline_confidence or "0")
    except ValueError:
        conf = 0.0
    analysis = analyze(args.log.read_text(encoding="utf-8", errors="replace"),
                       load_memory(args.memory), args.baseline_class, conf,
                       engine=args.engine, force_ai=args.force_ai)
    args.report.write_text(to_markdown(analysis), encoding="utf-8")
    args.json.write_text(json.dumps(analysis, indent=2), encoding="utf-8")
    print(f"{analysis['status']}: {analysis['predicted_category']} (details: {args.report})")


if __name__ == "__main__":
    main()

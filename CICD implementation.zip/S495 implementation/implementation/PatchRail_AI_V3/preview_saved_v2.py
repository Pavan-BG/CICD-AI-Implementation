"""Re-score SAVED V2 candidate outputs with V3 evidence guard, without rerunning MiniLM.

This is a POST-HOC sensitivity preview only: guard rules were informed by test
set errors and were not independently validated. Do not report as fresh AI run.
"""
from __future__ import annotations
import argparse,csv,json,sys
from pathlib import Path
from evidence_gate_v3 import check_evidence
from evaluate import coarse


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--v2-cases',required=True,type=Path,help='results_windows_v2/case_results.csv')
    p.add_argument('--patchrail-root',required=True,type=Path)
    p.add_argument('--output-dir',type=Path,default=Path('v3_saved_preview'))
    a=p.parse_args()
    if not a.v2_cases.is_file():p.error('Missing saved V2 CSV')
    with a.v2_cases.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    if not rows: p.error('CSV is empty')
    # Support original V2 case_results.csv and the later case-audit export.
    if {'file','method','predicted_class','truth','raw_baseline_class'}.issubset(rows[0]):
        pass
    elif {'file','method','prediction','provisional_truth','baseline_class'}.issubset(rows[0]):
        rows=[{**r,'predicted_class':r['prediction'],'truth':r['provisional_truth'],
                 'raw_baseline_class':r['baseline_class'],
                 'correct':r['correct_under_provisional_truth']} for r in rows]
    else:
        p.error('Expected V2 case_results.csv or all_cases_audit.csv with prediction details')
    outputs=[]
    for row in rows:
        if row['method'] not in ('minilm_v2','tfidf_v2'):continue
        f=a.patchrail_root/'examples'/'real-world'/row['file']
        if not f.is_file():raise FileNotFoundError(f)
        base=row['raw_baseline_class']
        proposal=row['predicted_class']; result=proposal; status='baseline_kept'
        verdict='not_applicable'; details='Original named diagnosis preserved'; evidence=''
        if base in ('unknown',''):
            if proposal in ('unknown',''):
                status='manual_review';result='unknown';verdict='no_candidate'
            else:
                check=check_evidence(proposal,f.read_text(encoding='utf-8',errors='replace'))
                verdict=check.decision;details=check.reason
                evidence=' | '.join(check.evidence_lines)
                result=check.category
                status='manual_review' if verdict=='unsupported' else 'suggestion_for_human_review'
        predicted=coarse(result) if result != 'build_failure' else 'build_failure'
        outputs.append({'file':row['file'],'method':row['method'],'baseline':base,
             'v2_candidate':proposal,'v3_investigation_hint':result,'post_hoc_guard':verdict,
             'reason':details,'provisional_truth':row['truth'],
             'v2_correct':row['correct'], 'post_hoc_v3_correct':int(predicted==row['truth']),
             'v2_named':int(row['predicted_coarse']!='insufficient_evidence'),
             'v3_named':int(predicted!='insufficient_evidence'),
             'evidence':evidence[:300], 'status':status})
    if not outputs: p.error('No V2 TF-IDF or MiniLM rows found')
    a.output_dir.mkdir(parents=True,exist_ok=True)
    with (a.output_dir/'saved_v2_candidate_guard_preview.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(outputs[0]));w.writeheader();w.writerows(outputs)
    summary=[]
    for method in ('tfidf_v2','minilm_v2'):
        part=[r for r in outputs if r['method']==method];n=len(part)
        if not n: continue
        v2correct=sum(int(r['v2_correct']) for r in part)
        v3correct=sum(r['post_hoc_v3_correct'] for r in part)
        v2named=sum(r['v2_named'] for r in part);v3named=sum(r['v3_named'] for r in part)
        v2wrong=sum(r['v2_named'] and not int(r['v2_correct']) for r in part)
        v3wrong=sum(r['v3_named'] and not r['post_hoc_v3_correct'] for r in part)
        summary.append({'method':method,'cases':n,'v2_correct':v2correct,'v3_preview_correct':v3correct,
           'v2_named':v2named,'v3_preview_named':v3named,
           'v2_wrong_named':v2wrong,'v3_preview_wrong_named':v3wrong})
    payload={'warning':'POST-HOC preview: V3 rules derived after V2 test-set error analysis. Not an independent accuracy result or live MiniLM V3 run.',
       'root_cause':'Evidence-checked human-review suggestions, not established root cause',
       'summaries':summary}
    (a.output_dir/'preview_metrics.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    md=['# V3 post-hoc saved prediction preview','', '**DO NOT CITE AS INDEPENDENT PERFORMANCE.** These are V2 predictions modified after examining the same test logs.','',
        '| Method | V2 correct | V3 preview correct | V2 named | V3 preview named | V2 wrong named | V3 preview wrong named |',
        '|---|---:|---:|---:|---:|---:|---:|']
    for m in summary:
        md.append(f'| {m["method"]} | {m["v2_correct"]} | {m["v3_preview_correct"]} | {m["v2_named"]} | {m["v3_preview_named"]} | {m["v2_wrong_named"]} | {m["v3_preview_wrong_named"]} |')
    (a.output_dir/'PREVIEW_REPORT.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
    print('\n'.join(md)); print('Saved:',a.output_dir.resolve())
if __name__=='__main__':main()

@echo off
setlocal
cd /d "%~dp0"
set "PATCHRAIL=%USERPROFILE%\Downloads\patchrail-main\patchrail-main"
if not exist "%PATCHRAIL%\src\patchrail" set "PATCHRAIL=%USERPROFILE%\Downloads\patchrail-main"
if not exist "%PATCHRAIL%\src\patchrail" (
  echo ERROR: PatchRail source not found in Downloads.
  echo Run manually: python evaluate_v3.py --patchrail-root "YOUR_PATCHRAIL_SOURCE_FOLDER" --engines tfidf minilm --output-dir results_windows_v3
  pause
  exit /b 1
)
python -m pytest -q tests
if errorlevel 1 (
  echo Unit tests failed; evaluation has not run.
  pause
  exit /b 1
)
python evaluate_v3.py --patchrail-root "%PATCHRAIL%" --engines tfidf minilm --output-dir results_windows_v3
if errorlevel 1 (
  echo Evaluation failed. See error above.
  pause
  exit /b 1
)
echo.
echo Completed. Open results_windows_v3\REPORT_V3.md for measured results.
pause

# What was actually tested here

- **16/16 local Python tests passed** (unit tests with artificial messages; not real-world machine-learning accuracy).
- The original PatchRail classifier was invoked through `integrate_v3.py` with real log paths for Pandas and Cabal, demonstrating a read-only adapter.
- Full TF-IDF comparison was executed against the unchanged 22 public real-world logs: PatchRail **9/22 correct, 12/22 named, four incorrect named**; TF-IDF V2 **9/22 correct, 13/22 named, five incorrect named**; TF-IDF V3 **9/22 correct, 12/22 named, four incorrect named**. This is **post-hoc** analysis.
- Existing uploaded Windows **MiniLM V2 predictions** were checked with Version 3 evidence rules **without rerunning MiniLM here**. This *preview* gives V2 **9/22 correct, 14 named, five incorrect named**; V3 preview **10/22 correct, 13 named, four incorrect named**, using researcher-mapped labels. This is NOT an independent validation.
- A fresh MiniLM V3 full inference run **has not** been performed in this environment, as its model files are unavailable here. The Windows user already has MiniLM installed, and `RUN_WINDOWS_V3.cmd` will perform that run.
- The Pandas source log has a nonfatal cache **warning**; Version 3 guards do not treat warnings as proof of a failed CI job. The Cabal log evidences a failed Haskell compilation but no Docker-specific failure, so a broad build investigation hint may be given but not a Docker diagnosis. Riverpod's Flutter lint failure does not support a publishing-failure diagnosis.

**No publication-grade improvement, root-cause certainty, enterprise reliability, or DORA metric change is claimed.**

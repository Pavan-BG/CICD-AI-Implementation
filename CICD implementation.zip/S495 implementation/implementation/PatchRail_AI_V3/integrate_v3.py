"""CLI: run unmodified PatchRail, then source-grounded V3 optional advice."""
import argparse, json, sys
from pathlib import Path
from enhanced_triage import Retriever
from triage_v3 import triage_v3, markdown
from ai_triage import load_memory
HERE = Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--patchrail-root',required=True,type=Path)
    p.add_argument('--log',required=True,type=Path)
    p.add_argument('--engine',choices=['tfidf','minilm'],default='minilm')
    p.add_argument('--memory',type=Path,default=HERE/'data'/'fixture_memory.jsonl')
    p.add_argument('--out-dir',type=Path,default=Path('integration_v3_results'))
    a=p.parse_args()
    if not (a.patchrail_root/'src'/'patchrail').is_dir():p.error('Invalid PatchRail source root')
    if not a.log.is_file():p.error(f'Log does not exist: {a.log}')
    sys.path.insert(0,str(a.patchrail_root.resolve()/'src'))
    from patchrail.ci.classify import classify_ci_log, redact_ci_log
    raw=a.log.read_text(encoding='utf-8',errors='replace')
    baseline=classify_ci_log(raw)
    clean=redact_ci_log(raw)['text']
    retriever=Retriever(load_memory(a.memory),a.engine)
    out=triage_v3(clean,baseline.get('failure_class') or 'unknown',float(baseline.get('confidence') or 0),retriever)
    a.out_dir.mkdir(parents=True,exist_ok=True)
    (a.out_dir/'patchrail_baseline.json').write_text(json.dumps(baseline,indent=2),encoding='utf-8')
    (a.out_dir/'v3_suggestion.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    (a.out_dir/'v3_report.md').write_text(markdown(out),encoding='utf-8')
    print(f'Original PatchRail: {baseline.get("failure_class")} (confidence {baseline.get("confidence")})')
    print(f'AI {a.engine} candidate: {out["candidate_category"]}')
    print(f'V3 decision: {out["status"]} / suggestion: {out["predicted_category"]}')
    print(f'Evidence verification: {out["evidence_decision"]} - {out["evidence_reason"]}')
    print('Read-only; human review required for every new AI suggestion. No CI state changes.')
    print('Reports:',a.out_dir.resolve())
if __name__=='__main__':main()

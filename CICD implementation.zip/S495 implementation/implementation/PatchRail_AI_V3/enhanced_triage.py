"""Read-only V2 similarity retriever.

Changes from V1: focus on diagnostic lines; pre-index incident memory once;
cache MiniLM model and embeddings; use best competing *category* for the
margin rather than the second incident of the same category. This module
never edits CI/deploy state. Similarity is not a calibrated probability.
"""
from __future__ import annotations
import re
import time
from pathlib import Path
from typing import Any
import numpy as np
from ai_triage import load_memory, redact, BASELINE_THRESHOLD

# Not fitted to held-out cases. Publish them in the report and tune only on an
# independent validation set in any future study.
DEFAULT_SIMILARITY = 0.52
DEFAULT_MARGIN = 0.025

ERROR_RE = re.compile(r'(?i)(assertionerror|failures?\s*[:=]|failed|fatal|exception|panic|\btimeout\b|timed out|not found|cannot|could not|undefined|\berror\b|exit (?:code|status)\s*[1-9]|##\[error\]|lint|typecheck|cannot compile|compile error|tests?\s+failed|error\s+CS\d+)')
DATE_RE = re.compile(r'^(?:\d{4}-\d\d-\d\d[T ]\d\d:\d\d:\d\d(?:[.,]\d+)?(?:Z|\+\d\d:\d\d)?\s*)+')
URL_RE = re.compile(r'https?://\S+')
ANSI_RE = re.compile(r'\x1b\[[0-9;]*m')


def focus(text: str, n: int = 14, max_chars: int = 2200) -> str:
    """Prioritize diagnostic signals over routine install / success chatter."""
    original = redact(text)
    lines = []
    for idx, raw in enumerate(original.splitlines()):
        ln = ANSI_RE.sub('', raw).replace('\\t', ' ')
        ln = DATE_RE.sub('', ln).strip()
        ln = URL_RE.sub('[URL]', ln)
        ln = re.sub(r'\s+', ' ', ln)[:400]
        if ln:
            lines.append((idx, ln))
    if not lines: return ''
    candidates = [(i, s) for i, s in lines if ERROR_RE.search(s)]
    # Select informative lines with different error evidence while retaining chronology
    selected = candidates[-n:] if candidates else lines[-min(n, 5):]
    unique = set(); dedup = []
    for i, s in selected:
        key = re.sub(r'\d+', '#', s.lower())
        if key in unique: continue
        unique.add(key); dedup.append((i, s))
    return '\n'.join(s for _, s in dedup)[-max_chars:]


class Retriever:
    def __init__(self, incidents: list[dict[str, Any]], engine: str = 'tfidf'):
        self.incidents = incidents
        self.engine = engine
        self.texts = [focus(x['log']) for x in incidents]
        self.model = None
        self.load_seconds = None
        if engine == 'tfidf':
            from sklearn.feature_extraction.text import TfidfVectorizer
            self.char = TfidfVectorizer(analyzer='char_wb', ngram_range=(3,5), min_df=1, sublinear_tf=True)
            self.words = TfidfVectorizer(analyzer='word', ngram_range=(1,2), token_pattern=r'(?u)\b\w+\b', sublinear_tf=True)
            self.char_mat = self.char.fit_transform(self.texts)
            self.word_mat = self.words.fit_transform(self.texts)
        elif engine == 'minilm':
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError as e:
                raise ImportError('MiniLM requires: python -m pip install -r requirements-hf.txt') from e
            t0 = time.perf_counter()
            self.model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
            self.matrix = np.asarray(self.model.encode(self.texts, normalize_embeddings=True, show_progress_bar=False))
            self.load_seconds = time.perf_counter() - t0
        else:
            raise ValueError('Unknown engine '+engine)

    def similarities(self, query: str) -> np.ndarray:
        if self.engine == 'minilm':
            vector = np.asarray(self.model.encode([query], normalize_embeddings=True, show_progress_bar=False))[0]
            return self.matrix @ vector
        vchar = self.char.transform([query]); vword = self.words.transform([query])
        return np.asarray(0.55*(self.char_mat @ vchar.T).toarray().ravel() +
                          0.45*(self.word_mat @ vword.T).toarray().ravel())

    def predict(self, log: str, baseline_class: str, baseline_confidence: float,
                similarity_threshold: float = DEFAULT_SIMILARITY,
                margin_threshold: float = DEFAULT_MARGIN) -> dict[str, Any]:
        class_name = (baseline_class or 'unknown').strip()
        # Preserve every named baseline diagnosis. Flagging possible mistakes is future work.
        base_kept = class_name.lower() not in ('unknown', '')
        result = {'status': 'baseline_kept' if base_kept else 'manual_review',
                  'predicted_category': class_name if base_kept else 'unknown',
                  'baseline_class': class_name,
                  'baseline_confidence': baseline_confidence,
                  'engine': self.engine,
                  'similarity': None, 'similarity_margin': None,
                  'matched_incident_id': None,
                  'evidence_excerpt': focus(log),
                  'suggested_action': 'Keep the existing diagnosis' if base_kept else 'Review failure evidence manually',
                  'changes_ci_status': False, 'auto_retry': False}
        if base_kept or not result['evidence_excerpt']: return result
        similarities = self.similarities(result['evidence_excerpt'])
        order = np.argsort(-similarities)
        topidx = int(order[0]); best = self.incidents[topidx]
        top = float(similarities[topidx]); other_score = 0.0
        for idx in order[1:]:
            if self.incidents[int(idx)]['category'] != best['category']:
                other_score = float(similarities[int(idx)])
                break
        gap = top - other_score
        result.update(similarity=round(top, 4), similarity_margin=round(gap, 4), matched_incident_id=best['id'])
        if top >= similarity_threshold and gap >= margin_threshold:
            result.update(status='ai_suggestion_review_required',predicted_category=best['category'],
                          suggested_action=best['advice'])
        return result


def load_fixture_memory(path: Path) -> list[dict[str, Any]]:
    return load_memory(path)

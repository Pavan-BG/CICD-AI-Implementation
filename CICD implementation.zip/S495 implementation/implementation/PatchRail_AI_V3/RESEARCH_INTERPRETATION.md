# Version 3: factual results, limitations, and thesis placement

## Purpose

Version 2 produced extra suggestions but also more unsupported named outcomes. Version 3 adds source-grounded checks and removes warning-only evidence. Under the same sample-specific provisional labels, a previously suggested Pandas cache failure was not supported by a fatal job error; the warning concerns cache reservation, not demonstrated job root cause. A Cabal log shows a failed Haskell build but does not justify claiming that Docker was involved, so the recommendation is downgraded to a broad **build-failure investigation hint**. A Riverpod lint error cannot substantiate a release-publish failure.

## Executed local tests

- `python -m pytest -q tests`: **16 passed** (synthetic unit tests, not a real-world validation).
- `python evaluate_v3.py --engines tfidf`: on the 22 existing real-world logs, original PatchRail 9/22 correct under provisional labels and 4 incorrect named; TF-IDF V2 9/22 and 5 incorrect named; TF-IDF V3 9/22 and 4 incorrect named. Named coverage: 54.55%, 59.09%, 54.55%, respectively. These are **post-hoc**, not a new generalisation result.
- Re-evaluation of the SAVED Windows MiniLM V2 case predictions with V3 evidence rules (without running MiniLM anew): MiniLM V2 9/22 correct and 5 incorrect named; V3 **preview** 10/22 correct and 4 incorrect named, 13/22 named suggestions. **This is a post-hoc sensitivity preview only**, not evidence that MiniLM V3 has been independently evaluated on new logs.

## What can be said in the thesis

> A read-only, evidence-aware hybrid CI-failure triage prototype was developed using the original PatchRail rule-based classifier, a pretrained MiniLM embedding model and source-specific evidence checks. Error analysis demonstrated that some high-similarity matches lacked causal support in the actual failure logs. The evidence gate prevented unsupported suggestions and could retain broader investigation hints when a precise tool-specific inference was not justified. On an exploratory 22-log test set, results were sensitive to category definitions and abstention scoring. Because V3 rules were specified after inspecting this set, no independent improvement in diagnostic accuracy is claimed.

The result that **V3 implementation runs and rejects unsupported suggestions** is distinct from a claim that it generalises. Appropriate next stages: secure new independent public logs, independently label each root cause (including 'insufficient evidence' option), freeze rules before evaluation, report confidence intervals and a paired test, and check the workflow on live GitHub Actions.

## Suggested captions after running Windows MiniLM V3

- **Figure 19:** Evidence-aware classification correctness of PatchRail, TF-IDF V2/V3 and MiniLM V2/V3 across 22 previously examined real-world logs (post-hoc exploratory assessment).
- **Figure 20:** Named investigation suggestion coverage before and after evidence checks across the five diagnostic configurations.
- **Figure 21:** Incorrect named recommendations under provisional broad-category labels, highlighting the effect of source-evidence verification.
- **Figure 22:** Mean processing time per log, including amortised model and memory-index setup costs, for the compared configurations.

Do not call these figures **independently validated improvements**. Baseline metrics can vary across systems because timing is host-dependent.

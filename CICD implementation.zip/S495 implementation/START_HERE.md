# FINAL IMPLEMENTATION PACKAGE

## Assessing the impact of CI/CD pipeline automation on software delivery performance

**Research prototype:** Original PatchRail v0.7.6 + TF-IDF/MiniLM semantic retrieval + confidence-aware, log-evidence verification (Version 3).  
**Created for:** master's dissertation implementation and reproducibility evidence.  
**Status:** functioning Python prototype with local tests and comparative results. Independent external validation and a hosted GitHub Actions execution remain outstanding.

### What is included

1. `upstream/patchrail-main/` contains the complete, unchanged original PatchRail project, including its Apache-2.0 `LICENSE`, source code, fixtures, example real-world logs, tests and documentation. **This is third-party source code, not the researcher's original system.**
2. `implementation/PatchRail_AI_V3/` contains the full AI research extension, code for Version 1 and Version 2 comparisons, the Version 3 evidence checks, unit tests, illustrative and fixture-derived incident memory, and evaluation scripts.
3. `evidence/reproduced_here/` contains the exact baseline benchmark (223/223), the 16-test Version 3 output, an offline TF-IDF re-run on 22 logs, measured charts/CSVs, and safe single-log sample reports.
4. `evidence/user_windows_screenshots/` contains 22 provided thesis figures plus supporting execution images.
5. `evidence/user_windows_v3_results/` contains a clearly identified transcription of the full five-method **Windows run already supplied by the researcher**, together with the actual graphs shown. This is observational evidence, not fresh verification by the packager.
6. `evidence/user_windows_case_audit/` contains the seven case-audit files supplied after the Windows experiments, with provisional findings and independent-review template.
7. `.github/workflows/research-ci-triage.yml` is an **optional, ready-to-run** demonstration workflow. It has **not** been executed on GitHub in this package.
8. `RUN_WINDOWS_FULL.cmd`, `RUN_WINDOWS_OFFLINE.cmd`, and `RUN_WINDOWS_SETUP.cmd` use paths relative to this extracted folder. The tests and experiments can be repeated without separately downloading PatchRail.

### How to run on Windows 10/11

**Step 1:** Right-click this ZIP and select **Extract All**. The extracted folder must contain this README, `upstream`, and `implementation` at the same level.

**Step 2:** Open **Command Prompt** inside this folder. Run `RUN_WINDOWS_SETUP.cmd` to install Python dependencies if needed. The MiniLM model is downloaded from Hugging Face on its first run; its large weights are **not included in this ZIP**.

**Step 3:** Double-click `RUN_WINDOWS_FULL.cmd` or run that filename in Command Prompt. The script executes the original benchmark, Version 3's 16 tests, all five comparative configurations and two single-log demonstrations. The generated files go to `RUN_OUTPUT/`.

**Alternative, without AI model downloads:** Run `RUN_WINDOWS_OFFLINE.cmd` to compare original PatchRail with TF-IDF V2 and TF-IDF V3. This is useful where Hugging Face is unavailable. Its results must not be presented as MiniLM results.

**Step 4:** Verify `RUN_OUTPUT/patchrail_benchmark.json`, `RUN_OUTPUT/unit_tests.txt`, `RUN_OUTPUT/comparison/REPORT_V3.md`, `RUN_OUTPUT/comparison/metrics_v3.json`, `RUN_OUTPUT/comparison/case_results_v3.csv`, and the four figures.

**Step 5:** For supplementary repository evidence, push the extracted contents to a GitHub repository and manually launch the `research-ci-triage` workflow under GitHub Actions; only then capture a real hosted workflow run. The included workflow is not proof that hosted CI has been executed.

### Command for a single MiniLM diagnosis

```cmd
python "implementation\PatchRail_AI_V3\integrate_v3.py" --patchrail-root "upstream\patchrail-main" --log "upstream\patchrail-main\examples\real-world\cabal-29562439929-excerpt.log" --engine minilm --out-dir "RUN_OUTPUT\single_log_cabal"
```

### Reported result and limits

The **user-provided Windows V3 experiment** reports 10/22 (45.45%) broad-label correctness, 59.09% named coverage, four incorrect named suggestions and 1.1799 s/log (amortised setup). The unchanged PatchRail baseline has 9/22 (40.91%), 54.55%, four incorrect suggestions and 0.1772 s/log on that run. These are *post-hoc, provisionally labelled* results. A new independent held-out test is needed before claiming improved accuracy or software delivery performance. New diagnoses are advisory and the existing CI failure status is never changed.

See `RESULTS_INTERPRETATION.md`, `ATTRIBUTION_AND_LICENSE.md`, `evidence/FIGURE_INDEX.md` and `evidence/user_windows_v3_results/WINDOWS_REPORT_AS_PROVIDED.md`.

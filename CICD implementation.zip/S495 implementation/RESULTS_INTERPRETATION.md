# How to describe the implementation in the dissertation

## The implemented engineering contribution

An external extension runs **unmodified PatchRail** first. Where the existing rule-based classifier already provides a named diagnosis, that result remains unchanged. For unknown cases, the extension retrieves similar incidents using TF-IDF or a pretrained MiniLM embedding model. The Version 3 stage checks error-line evidence and can reject an unsupported category or provide only a broad investigation hint. Every new AI suggestion requires human verification. Neither the original pipeline exit status nor any deployment approval is modified.

## Evidence hierarchy

- **Confirmed here:** original PatchRail's 223/223 bundled *curated fixture* benchmark; all 16 V3 unit tests; TF-IDF V2/V3 evaluation on 22 logs using the provisional labels; direct TF-IDF single-log demonstrations. These are provided as machine-readable artefacts in `evidence/reproduced_here`.
- **Observed on user's Windows computer:** all five methods, including MiniLM V2 and V3, on the same 22 cases; values and four graphs are reproduced from user-provided output in `evidence/user_windows_v3_results`.
- **NOT performed:** independent blinded label adjudication on fresh cases, real developer time-to-diagnose study, measurement of deployment frequency/recovery, or hosted GitHub Actions execution.

## Numerical findings and cautions

The user-reported MiniLM V3 result of 10/22 versus 9/22 for PatchRail is one additional correctly handled broad-label case through conservative abstention, **not new automatic root-cause discovery**. More named suggestions can also yield more false suggestions. The method is slower than PatchRail and requires independent validation. The study taxonomy disagrees with PatchRail maintainer-accepted broad answers and deliberate `unknown` cases.

The 96 historical memory entries are *synthetic fixture-derived*, not an independently sourced real incident corpus. The 22 test logs are public but labels are provisional. Thresholds and Version 3 safety rules are not validated on independent held-out records. In reports, use 'incremental engineering contribution' rather than 'first AI model' or 'proven superiority'.

# Upstream source provenance

Bundled source: the exact extracted tree from the user-supplied `patchrail-main.zip` attachment, PatchRail v0.7.6, original Apache-2.0 licensed source. It was not modified by the AI extension. Original uploaded ZIP SHA256: `8bbfa7af2b6b4a6d02a54df117ed7503c87d6aa1afc8c813a0e4681483680f2b`.

The archive is unpacked at `upstream/patchrail-main` and accompanies the external research implementation. The original ZIP archive itself is not duplicated inside this submission to avoid unnecessary size. This package provides all source files and data needed for the described experiment.

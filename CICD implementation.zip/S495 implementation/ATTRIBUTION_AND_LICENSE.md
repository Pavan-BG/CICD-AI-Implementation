# Authorship, provenance and licence notes

**Third-party baseline:** PatchRail v0.7.6, by the PatchRail project's credited author(s), including Pablo Guillén (see `upstream/patchrail-main/pyproject.toml`). Original project URL: https://github.com/patchrail/patchrail . License: Apache License 2.0, preserved exactly at `upstream/patchrail-main/LICENSE`.

**Research extension:** The external `implementation/PatchRail_AI_V3` is a separate Python prototype assembled for this dissertation's implementation work. Its design and results must be attributed as an extension to the existing PatchRail project, not a newly created CI/CD platform. It uses pretrained `sentence-transformers/all-MiniLM-L6-v2` from Hugging Face when available, with separate installation and model licence terms. Model weights are **not redistributed** in the ZIP.

**Evaluation evidence:** Original public real-world examples and curated fixtures come from the PatchRail project. The 22 broad category labels are provisional researcher mappings. Images under `evidence/user_windows_screenshots` are supplied by the researcher; they are not fabricated screenshots. File hashes preserve their bytes.

**Licence notice:** Reuse of upstream files must comply with their included Apache 2.0 licence. Bundling this repository for academic submission does not transfer ownership of the original open-source code. Other Python dependencies retain their own licences.
